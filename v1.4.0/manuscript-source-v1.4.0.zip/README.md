# Submission materials v1.4.0

Cross-Domain Skill Composition: Minimum Coupling and Cubic Stress in Generated Policies

The paper leads with A1 minimum coupling, A2 cubic stress and A5 as an adoption counterexample. The same five v1.3 retrospective case IDs and all original aggregate results are preserved. New paired statistics and exact-motif counts use saved data only. Source perspectives, mathematical hints and observed artifacts remain distinguished.

`main.pdf` contains six body pages, one reference page and one summary page. `main.tex`, `kaia.cls` and `images/` use the unmodified official class and its default margins/font sizes. `easychair_korean_abstract.md` supplies the matching title and Korean abstract. Compile from this folder with `tectonic -X compile main.tex` (a working TeX bundle/cache is needed). No model or simulator is invoked by compilation.

Table 1 presents all five exact expressions and judgments. Table 2 pairs saved raw rewards. Tables 3-4 give inputs; Table 5 and Figure 2 preserve the original aggregate result. Figure 1 illustrates mathematical response shapes, not new observations.

Public repository: https://github.com/7065616b/symbolic-policy-framing-pilot; versioned artifacts: `v1.4.0/`. Earlier release assets remain unchanged. This update is not a conference submission.
