# v1.4.0 revision

Emphasize the interesting outputs rather than catalogue bookkeeping: A1 minimum coupling and A2 cubic stress, with A5 showing why reference exceedance need not justify adoption. All five fixed posthoc cases remain, as do original negative aggregate results and limitations. Added paired seed-by-seed descriptive summaries for all matched original winners and an exact-string motif census with session denominators. Neutral-condition occurrences are explicitly reported.

No source-domain mechanism, practical deployment value, new mathematical invention, runtime efficiency, inferential significance or general superiority is claimed. No research model calls, environment traces or statistical simulations were added. Original evidence and v1.3 archives are unchanged. The new two-panel illustration shows formulas only. Input/domain provenance and historical feedback/selection/test distinctions remain intact.
