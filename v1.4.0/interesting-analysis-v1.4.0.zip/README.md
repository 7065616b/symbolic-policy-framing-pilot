# Interesting saved-artifact analysis v1.4.0

This directory analyzes five **fixed, posthoc** cases A1–A5 selected in v1.3.0. It reads saved public artifacts only. It does not call a research model, rerun an environment, simulate data, select new candidates, or change earlier archives.

## Reproduce

Run from the repository root with Python 3.10 or newer:

```powershell
python outputs/interesting_analysis_v1.4.0/analysis.py --catalog outputs/artifact_analysis_v1.3.0/catalog.json --cases outputs/artifact_analysis_v1.3.0/cases.json --final outputs/public_supplement/data/final.json --output outputs/interesting_analysis_v1.4.0
python -m unittest discover -s outputs/interesting_analysis_v1.4.0 -p test_analysis.py -v
```

No third-party packages are needed. The script checks the v1.3.0 cases-to-catalog SHA-256 link and records SHA-256 hashes of all three input files in `evidence.json`.

## Outputs

- `evidence.json`: machine-readable case metadata, 30 paired comparisons, motif census, motif session rows, definitions, and source hashes.
- `paired_case_comparisons.csv`: each A1–A5 policy compared with its domain reference and the five original winners in its own domain and block, including its own condition (an exact self-tie).
- `motif_sessions.csv`: each session containing either exact motif, matching slots, first matching round, and original-winner status.
- `report.md`: compact Korean summary of every case and condition, including adverse results.

Every comparison joins **all 600 shared test seeds** by the stored integer `seed`; duplicate, missing, nonfinite, or mismatched seed/reference data fail. The margin is case `raw` minus comparator `raw`, or case `raw` minus `referenceRaw` for the reference. Win/tie/loss uses an absolute `1e-12` raw-reward tolerance. The lower tail is the fifth percentile of the 600 margins using linear interpolation at index `(n-1)*0.05`; maximum loss is `max(0, -minimum margin)`. Nodes and depth are saved evaluator metadata, not recomputed AST values.

The motif census examines all **1,080 submission occurrences** (90 sessions × 12 slots), with 72 occurrences per domain-condition cell. It strips expression whitespace and searches for the contiguous literal `min(drift,burst)` in Network or `stress*stress*stress` in Thermal. These are observed strings, not semantic equivalence classes. The 600 test seeds are synthetic trace variations, not independent model generations; the 90 sessions are the units of model generation. The cases were selected after inspecting saved outputs, so their margins are descriptive and do not support confirmatory significance or causal claims.

## From downloaded archives

Unzip the v1.4 analysis into `interesting-analysis-v1.4.0/`, the unchanged v1.3 artifact archive into `artifact-analysis-v1.3.0/`, and the original public archive into `public-supplement-v1.0.0/`. These are folder names you choose on extraction. Run in their parent directory:

```powershell
python interesting-analysis-v1.4.0/analysis.py --catalog artifact-analysis-v1.3.0/catalog.json --cases artifact-analysis-v1.3.0/cases.json --final public-supplement-v1.0.0/data/final.json --output replay
python -m unittest discover -s interesting-analysis-v1.4.0 -p test_analysis.py -v
```

Compare the four regenerated files (`evidence.json`, the two CSV files and `report.md`) with those in the analysis archive. Source hashes and descriptive records are deterministic. The PDF uses a hand-authored mathematical illustration; it adds no sampled observations.
