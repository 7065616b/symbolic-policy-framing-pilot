"""Saved-artifact, paired descriptive analysis. No evaluator or RNG calls."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
from pathlib import Path

CONDITIONS = ("N_FLAT", "N_ROLE", "X_FLAT", "X_ROLE", "DOMAIN_V2")
CASE_LOCATIONS = {
    "A1": ("Network", 4, "X_ROLE", 7),
    "A2": ("Thermal", 5, "X_ROLE", 10),
    "A3": ("Cloud", 1, "X_ROLE", 7),
    "A4": ("Thermal", 3, "X_FLAT", 9),
    "A5": ("Network", 5, "X_ROLE", 10),
}
MOTIFS = {"Network": "min(drift,burst)", "Thermal": "stress*stress*stress"}
TOL = 1e-12


def fail(message: str) -> None:
    raise ValueError(message)


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def seed_map(policy: dict, label: str) -> dict[int, dict]:
    traces = policy.get("perSeed")
    if not isinstance(traces, list) or len(traces) != 600:
        fail(f"{label}: expected 600 perSeed traces")
    result = {}
    for trace in traces:
        if not isinstance(trace, dict) or not all(k in trace for k in ("seed", "raw", "referenceRaw")):
            fail(f"{label}: malformed trace")
        seed = trace["seed"]
        if not isinstance(seed, int) or seed in result:
            fail(f"{label}: duplicate or invalid seed {seed!r}")
        if not all(isinstance(trace[k], (int, float)) and math.isfinite(trace[k]) for k in ("raw", "referenceRaw")):
            fail(f"{label}: nonfinite reward")
        result[seed] = trace
    if len(result) != 600:
        fail(f"{label}: expected 600 unique seeds")
    if not math.isclose(statistics.mean(t["raw"] for t in result.values()), policy["meanRaw"], abs_tol=TOL, rel_tol=0):
        fail(f"{label}: saved meanRaw differs from traces")
    if not math.isclose(statistics.mean(t["referenceRaw"] for t in result.values()), policy["referenceMeanRaw"], abs_tol=TOL, rel_tol=0):
        fail(f"{label}: saved referenceMeanRaw differs from traces")
    return result


def paired_margins(left: dict[int, dict], right: dict[int, dict], reference: bool = False) -> list[float]:
    if len(left) != 600 or set(left) != set(right):
        fail("paired comparison requires identical sets of 600 seeds")
    margins = []
    for seed in sorted(left):
        a, b = left[seed], right[seed]
        if abs(a["referenceRaw"] - b["referenceRaw"]) > TOL:
            fail(f"seed {seed}: referenceRaw differs between sessions")
        margins.append(a["raw"] - (b["referenceRaw"] if reference else b["raw"]))
    return margins


def summarize(margins: list[float]) -> dict:
    if len(margins) != 600:
        fail("expected 600 paired margins")
    ordered = sorted(margins)
    wins = sum(x > TOL for x in margins)
    ties = sum(abs(x) <= TOL for x in margins)
    losses = sum(x < -TOL for x in margins)
    return {
        "seedCount": 600, "wins": wins, "ties": ties, "losses": losses,
        "meanMargin": statistics.mean(margins),
        "medianMargin": statistics.median(margins),
        "p05Margin": ordered[29] + .95 * (ordered[30] - ordered[29]),
        "minimumMargin": ordered[0],
        "maximumLoss": max(0.0, -ordered[0]),
    }


def compact(expr: str) -> str:
    return "".join(expr.split())


def motif_census(rows: list[dict]) -> tuple[list[dict], list[dict]]:
    by_session = {}
    counts = {}
    for row in rows:
        domain, condition = row["domain"], row["condition"]
        key = (domain, condition)
        counter = counts.setdefault(key, {"occurrences": 0, "originalWinners": 0, "denominator": 0, "sessions": set()})
        counter["denominator"] += 1
        session = row["sessionId"]
        info = by_session.setdefault(session, {"domain": domain, "condition": condition, "block": row["block"], "matchingSlots": [], "slots": set(), "winners": []})
        if (info["domain"], info["condition"], info["block"]) != (domain, condition, row["block"]):
            fail(f"inconsistent session {session}")
        if row["slot"] in info["slots"]:
            fail(f"duplicate slot in {session}")
        info["slots"].add(row["slot"])
        if row["isOriginallySelected"]:
            info["winners"].append(row["slot"])
        motif = MOTIFS.get(domain)
        if motif and motif in compact(row["expr"]):
            info["matchingSlots"].append(row["slot"])
            counter["occurrences"] += 1
            counter["originalWinners"] += bool(row["isOriginallySelected"])
            counter["sessions"].add(session)
    if len(rows) != 1080 or len(by_session) != 90:
        fail("catalog must have 1080 occurrences in 90 sessions")
    if any(v["denominator"] != 72 for v in counts.values()) or len(counts) != 15:
        fail("expected 72 occurrences in each of 15 domain-condition cells")
    session_rows = []
    for session, info in sorted(by_session.items()):
        if info["slots"] != set(range(1, 13)) or len(info["winners"]) != 1:
            fail(f"expected slots 1–12 and one original winner in {session}")
        if info["matchingSlots"]:
            slots = sorted(info["matchingSlots"])
            session_rows.append({"sessionId": session, "domain": info["domain"], "condition": info["condition"],
                                 "block": info["block"], "motif": MOTIFS[info["domain"]],
                                 "matchingSlots": ";".join(map(str, slots)), "firstRound": (slots[0] - 1) // 3 + 1,
                                 "occurrences": len(slots), "originalWinnerSlot": info["winners"][0],
                                 "originalWinnerHasMotif": info["winners"][0] in slots})
    census = []
    for domain in ("Network", "Thermal", "Cloud"):
        for condition in CONDITIONS:
            item = counts[(domain, condition)]
            census.append({"domain": domain, "condition": condition, "motif": MOTIFS.get(domain, ""),
                           "denominatorOccurrences": item["denominator"], "motifOccurrences": item["occurrences"],
                           "sessionsWithMotif": len(item["sessions"]), "originalWinnersWithMotif": item["originalWinners"]})
    return census, session_rows


def analyze(catalog: dict, cases: dict, final: dict) -> tuple[dict, list[dict], list[dict]]:
    rows = catalog["rows"]
    indexed_rows = {(r["sessionId"], r["slotId"]): r for r in rows}
    sessions = {s["id"]: s for s in final["sessions"]}
    if len(sessions) != 90 or len(indexed_rows) != 1080:
        fail("duplicate or missing sessions/catalog rows")
    by_case = {c["caseId"]: c for c in cases["cases"]}
    if set(by_case) != set(CASE_LOCATIONS):
        fail("case IDs differ from fixed A1–A5")
    comparisons = []
    case_meta = []
    for case_id, (domain, block, condition, slot) in CASE_LOCATIONS.items():
        case = by_case[case_id]
        if (case["domain"], case["block"], case["condition"], case["slot"]) != (domain, block, condition, slot):
            fail(f"{case_id}: fixed location mismatch")
        catalog_row = indexed_rows.get((case["sessionId"], case["slotId"]))
        if catalog_row is None or any(catalog_row[k] != case[k] for k in ("expr", "nodes", "depth", "isOriginallySelected")):
            fail(f"{case_id}: catalog mismatch")
        if not case["isOriginallySelected"]:
            fail(f"{case_id}: not an original winner")
        selected = sessions[case["sessionId"]]["selectedPolicy"]
        if selected["slotId"] != case["slotId"] or selected["expr"] != case["expr"]:
            fail(f"{case_id}: selectedPolicy mismatch")
        left = seed_map(selected, case_id)
        case_meta.append({"caseId": case_id, "sessionId": case["sessionId"], "slotId": case["slotId"],
                          "domain": domain, "block": block, "condition": condition, "expression": case["expr"],
                          "nodes": case["nodes"], "depth": case["depth"]})
        comparators = {c["condition"]: c for c in case["comparators"]}
        if set(comparators) != set(CONDITIONS):
            fail(f"{case_id}: expected all five original winner arms")
        targets = [("reference", "reference", sessions[case["sessionId"]], None)]
        for arm in CONDITIONS:
            comp = comparators[arm]
            s = sessions[comp["sessionId"]]
            policy = s["selectedPolicy"]
            if s["condition"] != arm or s["domainId"] != case["domainId"] or comp["block"] != block:
                fail(f"{case_id}/{arm}: domain/block/condition mismatch")
            if policy["slotId"] != comp["slotId"] or not indexed_rows[(comp["sessionId"], comp["slotId"])]["isOriginallySelected"]:
                fail(f"{case_id}/{arm}: comparator is not original winner")
            if policy["expr"] != comp["expr"] or policy["nodes"] != comp["nodes"] or policy["depth"] != comp["depth"]:
                fail(f"{case_id}/{arm}: comparator metadata mismatch")
            targets.append(("original_winner", arm, s, comp))
        for target_type, arm, s, comp in targets:
            right_policy = s["selectedPolicy"]
            margins = paired_margins(left, seed_map(right_policy, f"{case_id}/{arm}"), target_type == "reference")
            comparisons.append({"caseId": case_id, "domain": domain, "block": block,
                                "caseCondition": condition, "caseSlotId": case["slotId"],
                                "caseNodes": case["nodes"], "caseDepth": case["depth"],
                                "comparatorType": target_type, "comparatorCondition": arm,
                                "comparatorSessionId": s["id"] if comp else "",
                                "comparatorSlotId": comp["slotId"] if comp else "",
                                "comparatorNodes": comp["nodes"] if comp else "",
                                "comparatorDepth": comp["depth"] if comp else "",
                                **summarize(margins)})
    census, motif_sessions = motif_census(rows)
    evidence = {"scope": "Descriptive posthoc analysis of five fixed saved cases; synthetic test traces are not independent model sessions.",
                "definitions": {"margin": "case raw minus comparator raw on the identical seed; reference uses referenceRaw",
                                "winTieLossTolerance": TOL,
                                "p05Margin": "linear interpolation at (n-1)*0.05 in ascending sorted margins",
                                "maximumLoss": "max(0, -minimumMargin)",
                                "motif": "exact contiguous substring after deleting all expression whitespace; no semantic normalization"},
                "cases": case_meta, "pairedComparisons": comparisons, "motifCensus": census,
                "motifSessions": motif_sessions}
    return evidence, comparisons, motif_sessions


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def report(evidence: dict) -> str:
    lines = ["# 흥미로운 사례의 저장 아티팩트 분석", "",
             "A1–A5는 사후 선택된 고정 사례다. 600개 시드는 합성 환경의 공통 테스트 추적이며 독립적인 모델 세션이 아니다. ",
             "평균 차이는 시드별 원점수(raw reward) 차이의 평균이다. 인과 효과, 생물학적 기전, 의미적 동등성을 주장하지 않는다.", "",
             "## 사례별 기준 정책 비교", "",
             "|사례|표현식|노드/깊이|평균 차이|승/무/패|5% 하위 차이|최대 손실|", "|---|---|---:|---:|---:|---:|---:|"]
    for case in evidence["cases"]:
        item = next(x for x in evidence["pairedComparisons"] if x["caseId"] == case["caseId"] and x["comparatorType"] == "reference")
        lines.append(f"|{case['caseId']}|`{case['expression']}`|{case['nodes']}/{case['depth']}|{item['meanMargin']:+.6f}|{item['wins']}/{item['ties']}/{item['losses']}|{item['p05Margin']:+.6f}|{item['maximumLoss']:.6f}|")
    lines += ["", "## 같은 도메인·블록의 원래 당선 정책과 비교", "",
              "아래 값은 사례 정책의 raw reward에서 각 조건의 원래 당선 정책 raw reward를 뺀 값이다. 각 행은 600개 공통 시드를 정확히 결합한다.", "",
              "|사례|조건|비교 정책 노드/깊이|평균 차이|승/무/패|5% 하위 차이|최대 손실|", "|---|---|---:|---:|---:|---:|---:|"]
    for x in evidence["pairedComparisons"]:
        if x["comparatorType"] != "original_winner":
            continue
        lines.append(f"|{x['caseId']}|{x['comparatorCondition']}|{x['comparatorNodes']}/{x['comparatorDepth']}|{x['meanMargin']:+.6f}|{x['wins']}/{x['ties']}/{x['losses']}|{x['p05Margin']:+.6f}|{x['maximumLoss']:.6f}|")
    lines += ["", "## 정확한 문자열 모티프 센서스", "",
              "공백을 제거한 표현식에서 `min(drift,burst)` (Network)와 `stress*stress*stress` (Thermal)의 정확한 연속 부분문자열만 센다. Cloud에는 지정된 모티프가 없어 비교 분모만 표기한다. 각 도메인·조건에 72회 제출(6세션 × 12슬롯)이 있다.", "",
              "|도메인|조건|모티프/제출|출현 세션/6|원래 당선 정책|", "|---|---|---:|---:|---:|"]
    for x in evidence["motifCensus"]:
        lines.append(f"|{x['domain']}|{x['condition']}|{x['motifOccurrences']}/{x['denominatorOccurrences']}|{x['sessionsWithMotif']}/6|{x['originalWinnersWithMotif']}|")
    lines += ["", "A1의 기준 정책 대비 평균 차이는 양수지만 일부 시드에서는 손실이 있다. A2는 기준 정책보다 599/600 시드에서 높지만, 더 단순한 X_FLAT 대안보다 높은 시드는 390/600이다. A5는 N_ROLE과 DOMAIN_V2의 원래 선택 정책보다 평균 차이가 음수여서 반례로 유지한다. A3·A4 및 다른 조건의 음수 또는 약한 결과도 위 표에 그대로 표시했다.", "",
              "`motif_sessions.csv`에는 각 모티프가 나타난 세션과 최초 라운드가 있다. 이 빈도는 관측된 문자열에 관한 것이며 수식의 의미적 동등성이나 힌트의 인과 작용을 판정하지 않는다.", ""]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--catalog", type=Path, default=Path("outputs/artifact_analysis_v1.3.0/catalog.json"))
    parser.add_argument("--cases", type=Path, default=Path("outputs/artifact_analysis_v1.3.0/cases.json"))
    parser.add_argument("--final", type=Path, default=Path("outputs/public_supplement/data/final.json"))
    parser.add_argument("--output", type=Path, default=Path("outputs/interesting_analysis_v1.4.0"))
    args = parser.parse_args()
    evidence, comparisons, motif_sessions = analyze(read_json(args.catalog), read_json(args.cases), read_json(args.final))
    if read_json(args.cases)["catalogSha256"] != sha256(args.catalog):
        fail("cases.json catalogSha256 does not match catalog.json")
    evidence["sourceSha256"] = {key: sha256(path) for key, path in (("catalog.json", args.catalog), ("cases.json", args.cases), ("final.json", args.final))}
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "evidence.json").write_text(json.dumps(evidence, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    write_csv(args.output / "paired_case_comparisons.csv", comparisons)
    write_csv(args.output / "motif_sessions.csv", motif_sessions)
    (args.output / "report.md").write_text(report(evidence), encoding="utf-8")
    print(f"Analyzed {len(evidence['cases'])} fixed cases; {len(comparisons)} comparisons; {len(motif_sessions)} motif sessions.")


if __name__ == "__main__":
    main()
