"""Unit checks for exact pairing and motif counting."""
import unittest

from analysis import motif_census, paired_margins, seed_map, summarize


def policy(raw_fn=lambda i: 1.0, reference_fn=lambda i: 1.0):
    traces = [{"seed": 1000 + i, "raw": raw_fn(i), "referenceRaw": reference_fn(i)} for i in range(600)]
    return {"perSeed": traces, "meanRaw": sum(x["raw"] for x in traces) / 600,
            "referenceMeanRaw": sum(x["referenceRaw"] for x in traces) / 600}


class PairingTests(unittest.TestCase):
    def test_shuffled_seed_order_is_irrelevant(self):
        left = seed_map(policy(lambda i: float(i % 7)), "left")
        other = policy(lambda i: float(i % 7) - 0.5)
        other["perSeed"].reverse()
        right = seed_map(other, "right")
        result = summarize(paired_margins(left, right))
        self.assertEqual((result["wins"], result["ties"], result["losses"]), (600, 0, 0))
        self.assertAlmostEqual(result["meanMargin"], 0.5)

    def test_mismatched_seed_set_fails(self):
        left = seed_map(policy(), "left")
        right = seed_map(policy(), "right")
        right[2000] = right.pop(1000)
        with self.assertRaisesRegex(ValueError, "identical sets"):
            paired_margins(left, right)

    def test_missing_traces_fail(self):
        bad = policy()
        bad["perSeed"].pop()
        with self.assertRaisesRegex(ValueError, "600 perSeed"):
            seed_map(bad, "bad")

    def test_duplicate_seed_fails(self):
        bad = policy()
        bad["perSeed"][1]["seed"] = bad["perSeed"][0]["seed"]
        with self.assertRaisesRegex(ValueError, "duplicate"):
            seed_map(bad, "bad")

    def test_tolerance_and_losses(self):
        values = [2e-12, 1e-13, -1e-13, -0.25] + [0.0] * 596
        result = summarize(values)
        self.assertEqual((result["wins"], result["ties"], result["losses"]), (1, 598, 1))
        self.assertEqual(result["maximumLoss"], 0.25)

    def test_reference_mismatch_fails(self):
        left = seed_map(policy(), "left")
        right = seed_map(policy(reference_fn=lambda i: 1.1 if i == 0 else 1.0), "right")
        with self.assertRaisesRegex(ValueError, "referenceRaw differs"):
            paired_margins(left, right)


class MotifTests(unittest.TestCase):
    def test_exact_whitespace_normalized_motif_and_first_round(self):
        rows = []
        for domain in ("Network", "Thermal", "Cloud"):
            for condition in ("N_FLAT", "N_ROLE", "X_FLAT", "X_ROLE", "DOMAIN_V2"):
                for block in range(1, 7):
                    session = f"{domain}-{condition}-{block}"
                    for slot in range(1, 13):
                        expr = "queue"
                        if domain == "Network" and condition == "X_ROLE" and block == 1 and slot in (4, 8):
                            expr = "queue+min( drift, burst )"
                        if domain == "Thermal" and condition == "N_FLAT" and block == 2 and slot == 10:
                            expr = "temp+stress * stress * stress"
                        rows.append({"sessionId": session, "domain": domain, "condition": condition,
                                     "block": block, "slot": slot, "expr": expr,
                                     "isOriginallySelected": slot == 8})
        census, sessions = motif_census(rows)
        network = next(x for x in census if x["domain"] == "Network" and x["condition"] == "X_ROLE")
        self.assertEqual((network["motifOccurrences"], network["sessionsWithMotif"], network["originalWinnersWithMotif"]), (2, 1, 1))
        self.assertEqual(next(x for x in sessions if x["domain"] == "Network")["firstRound"], 2)
        self.assertEqual(len(sessions), 2)


if __name__ == "__main__":
    unittest.main()
