# v1.6.0 editorial revision

- Replaced the five-case overview with supplied input → exact output → alternative → author judgment columns, distinguishing mathematical templates from source-domain guidance.
- Added an explicitly invented, normalized two-module A2 calculation. The simpler cubic rule selects P (1.112 vs 0.943); A2 selects Q (1.132 vs 1.263). The supplied product changes Q-minus-P by +0.300. Scores are not rewards; both policies already use cubic stress.
- Focused the narrative on the two observed adoption lessons, consolidated repeated numerical interpretation, and shortened the conclusion and summary. Methods, aggregate limitations and all earlier numerical comparison tables are preserved except renumbering.
- Retained the five case identities, exact expressions, cross-domain motivation, neutral-condition motif occurrences, test-coverage caveats, post-hoc selection and limits on causal/practical inference.
- Official class, font defaults and page geometry remain unchanged. Ragged-bottom layout prevents excessive interparagraph stretching.

All new arithmetic is explanatory only. There are no new model calls, evaluator runs, traces or statistical simulations.
