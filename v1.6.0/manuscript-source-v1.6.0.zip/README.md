# Submission materials v1.6.0

Cross-Domain Skill Composition: Minimum Coupling and Cubic Stress in Generated Policies

This editorial revision connects supplied hints, exact outputs, alternatives and author judgments in Table 1. Table 2 supplies an explicitly invented A2 arithmetic example. The empirical results and the v1.5.0 saved-data analysis are unchanged.

The central observations are that expanding the alternative set weakens A1's adoption case and that A2's highest observed mean still leaves a tradeoff against a simpler policy. Repeated numeric interpretations in the case narrative and conclusion were consolidated into the comparison section.

`main.pdf` has 7 body pages, one references page and one summary page (9 total). The official class, font defaults and margins are unchanged; ragged-bottom layout avoids stretched paragraph gaps. Seven tables and three figures are included. Table 3 gives positions, Table 4 gains/losses, Tables 5–6 inputs and Table 7 original aggregate results.

Compile `main.tex` in this folder with `tectonic -X compile main.tex` using a working TeX bundle/cache. The source ZIP includes `examples/worked_example.py`; run `python examples/worked_example.py --output replay.json` for exact decimal arithmetic without dependencies or network access. This is an invented pairwise choice example, not environment simulation or empirical validation.

Public repository: https://github.com/7065616b/symbolic-policy-framing-pilot. The prior catalogue, prompts, case-selection records, evidence and v1.5.0 alternative analysis remain public and unchanged. No new model calls, helper agents, environment runs, statistical simulations or conference submission were performed for this revision.
