"""Deterministic descriptive analysis of saved policies; no evaluation or sampling."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path

TOL = 1e-12
CASE_IDS = {"A1": ("Network", 4, "X_ROLE", 7), "A2": ("Thermal", 5, "X_ROLE", 10)}
ROOT = Path(__file__).resolve().parents[2]


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def finite(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{label}: expected finite number")
    return value


def competition_rank(value, values):
    finite(value, "rank value")
    return 1 + sum(finite(x, "rank peer") > value + TOL for x in values)


def pareto(rows, utility_key):
    """Return every strict dominator ID for each occurrence."""
    result = {}
    for row in rows:
        if row["slotId"] in result:
            raise ValueError("duplicate slotId in Pareto scope")
        utility = finite(row[utility_key], utility_key)
        nodes = finite(row["nodes"], "nodes")
        dominators = []
        for other in rows:
            if other["slotId"] == row["slotId"]:
                continue
            other_u = finite(other[utility_key], utility_key)
            other_n = finite(other["nodes"], "nodes")
            if other_u >= utility - TOL and other_n <= nodes + TOL and (other_u > utility + TOL or other_n < nodes - TOL):
                dominators.append(other["slotId"])
        result[row["slotId"]] = sorted(dominators)
    return result


def positions(rows, target):
    tested = [r for r in rows if r["testUtility"] is not None]
    if target["testUtility"] is None:
        test_rank = None
    else:
        test_rank = competition_rank(target["testUtility"], [r["testUtility"] for r in tested])
    return {
        "selectionRank": competition_rank(target["selectionUtility"], [r["selectionUtility"] for r in rows]),
        "selectionDenominator": len(rows),
        "testRank": test_rank,
        "testDenominator": len(tested),
        "testedCount": len(tested),
        "untestedCount": len(rows) - len(tested),
        "uniqueExactStrings": len({r["expr"] for r in rows}),
        "uniqueExactTestedStrings": len({r["expr"] for r in tested}),
    }


def selection_representative(dominator_ids, rows):
    """Pick a fixed descriptive comparator without consulting test outcomes."""
    if not dominator_ids:
        return None
    by_id = {r["slotId"]: r for r in rows}
    return by_id[sorted(dominator_ids)[0]]


def seed_map(policy, label):
    traces = policy.get("perSeed")
    if not isinstance(traces, list) or len(traces) != 600:
        raise ValueError(f"{label}: expected 600 perSeed traces")
    result = {}
    for t in traces:
        if not isinstance(t, dict) or any(k not in t for k in ("seed", "raw", "referenceRaw")):
            raise ValueError(f"{label}: malformed trace")
        seed = t["seed"]
        if isinstance(seed, bool) or not isinstance(seed, int) or seed in result:
            raise ValueError(f"{label}: duplicate or invalid seed")
        finite(t["raw"], f"{label} raw")
        finite(t["referenceRaw"], f"{label} referenceRaw")
        result[seed] = t
    for raw_key, mean_key in (("raw", "meanRaw"), ("referenceRaw", "referenceMeanRaw")):
        if abs(statistics.mean(t[raw_key] for t in result.values()) - finite(policy[mean_key], mean_key)) > TOL:
            raise ValueError(f"{label}: saved {mean_key} differs from traces")
    return result


def paired_margins(left, right, reference=False):
    if len(left) != 600 or set(left) != set(right):
        raise ValueError("paired comparison requires identical 600 integer seeds")
    margins = []
    for seed in sorted(left):
        a, b = left[seed], right[seed]
        if abs(a["referenceRaw"] - b["referenceRaw"]) > TOL:
            raise ValueError(f"seed {seed}: referenceRaw mismatch")
        margins.append(a["raw"] - (b["referenceRaw"] if reference else b["raw"]))
    return margins


def summarize(margins):
    if len(margins) != 600 or any(not math.isfinite(x) for x in margins):
        raise ValueError("expected 600 finite margins")
    ordered = sorted(margins)
    positive = [x for x in margins if x > 0]
    negative = [-x for x in margins if x < 0]
    gain = sum(positive) / 600
    loss = sum(negative) / 600
    mean = statistics.mean(margins)
    if not math.isclose(mean, gain - loss, abs_tol=TOL, rel_tol=0):
        raise ValueError("gain/loss decomposition mismatch")
    return {
        "seedCount": 600,
        "wins": sum(x > TOL for x in margins),
        "ties": sum(abs(x) <= TOL for x in margins),
        "losses": sum(x < -TOL for x in margins),
        "meanMargin": mean,
        "medianMargin": statistics.median(margins),
        "p05Margin": ordered[29] + .95 * (ordered[30] - ordered[29]),
        "worst30MeanMargin": statistics.mean(ordered[:30]),
        "maximumLoss": max(0.0, -ordered[0]),
        "maximumGain": max(0.0, ordered[-1]),
        "meanPositiveGain": statistics.mean(positive) if positive else None,
        "meanAbsoluteNegativeLoss": statistics.mean(negative) if negative else None,
        "gainContribution": gain,
        "lossContribution": loss,
    }


def validate_sources(catalog, cases, final):
    rows = catalog["rows"]
    if len(rows) != 1080 or len({r["slotId"] for r in rows}) != 1080:
        raise ValueError("expected 1080 unique catalog occurrences")
    sessions = final["sessions"]
    if len(sessions) != 90 or len({s["id"] for s in sessions}) != 90:
        raise ValueError("expected 90 distinct final sessions")
    by_session = {s["id"]: s for s in sessions}
    grouped = defaultdict(list)
    for r in rows:
        if r["sessionId"] not in by_session:
            raise ValueError("catalog session absent from final")
        grouped[r["sessionId"]].append(r)
    if set(grouped) != set(by_session):
        raise ValueError("session mismatch")
    winners = []
    for sid, group in grouped.items():
        if len(group) != 12 or {r["slot"] for r in group} != set(range(1, 13)):
            raise ValueError(f"{sid}: expected slots 1-12")
        chosen = [r for r in group if r["isOriginallySelected"]]
        if len(chosen) != 1:
            raise ValueError(f"{sid}: expected one original winner")
        r = chosen[0]
        s = by_session[sid]
        p = s["selectedPolicy"]
        if (r["slotId"], r["expr"], r["nodes"], r["depth"]) != (p["slotId"], p["expr"], p["nodes"], p["depth"]):
            raise ValueError(f"{sid}: winner mismatch")
        if abs(r["testUtility"] - p["utility"]) > TOL:
            raise ValueError(f"{sid}: test utility mismatch")
        winners.append(r)
    case_index = {c["caseId"]: c for c in cases["cases"]}
    if not set(CASE_IDS).issubset(case_index):
        raise ValueError("missing fixed case IDs")
    for cid, loc in CASE_IDS.items():
        c = case_index[cid]
        if (c["domain"], c["block"], c["condition"], c["slot"]) != loc:
            raise ValueError(f"{cid}: fixed location changed")
        r = next((r for r in winners if r["slotId"] == c["slotId"]), None)
        if r is None or r["sessionId"] != c["sessionId"] or r["expr"] != c["expr"]:
            raise ValueError(f"{cid}: fixed case not original winner")
    return rows, winners, by_session, case_index


def analyze(catalog, cases, final):
    rows, winners, sessions, case_index = validate_sources(catalog, cases, final)
    by_domain = defaultdict(list)
    winner_domain = defaultdict(list)
    for r in rows:
        by_domain[r["domain"]].append(r)
    for r in winners:
        winner_domain[r["domain"]].append(r)
    if {d: len(v) for d, v in winner_domain.items()} != {"Network": 30, "Thermal": 30, "Cloud": 30}:
        raise ValueError("expected 30 original winners per domain")
    if any(len(v) != 360 for v in by_domain.values()):
        raise ValueError("expected 360 submitted instances per domain")
    original = []
    case_positions = []
    case_id_by_slot = {case_index[cid]["slotId"]: cid for cid in CASE_IDS}
    for domain in sorted(winner_domain):
        group = sorted(winner_domain[domain], key=lambda r: (r["block"], r["condition"]))
        selection_dom = pareto(group, "selectionUtility")
        test_dom = pareto(group, "testUtility")
        selection_values = [r["selectionUtility"] for r in group]
        test_values = [r["testUtility"] for r in group]
        for r in group:
            item = {
                "caseId": case_id_by_slot.get(r["slotId"], ""), "domain": domain, "condition": r["condition"], "block": r["block"],
                "sessionId": r["sessionId"], "slotId": r["slotId"], "slot": r["slot"],
                "expr": r["expr"], "nodes": r["nodes"], "depth": r["depth"],
                "selectionUtility": r["selectionUtility"], "testUtility": r["testUtility"],
                "selectionRank30": competition_rank(r["selectionUtility"], selection_values),
                "testRank30": competition_rank(r["testUtility"], test_values),
                "selectionPareto": not selection_dom[r["slotId"]], "testPareto": not test_dom[r["slotId"]],
                "selectionDominatorCount": len(selection_dom[r["slotId"]]), "selectionDominatorIds": selection_dom[r["slotId"]],
                "testDominatorCount": len(test_dom[r["slotId"]]), "testDominatorIds": test_dom[r["slotId"]],
            }
            original.append(item)
            scope = positions(by_domain[domain], r)
            case_positions.append({k: item[k] for k in ("caseId", "domain", "condition", "block", "sessionId", "slotId", "expr", "selectionUtility", "testUtility")} | scope)
    comparisons = []
    case_status = []
    trace_cache = {}
    for cid in CASE_IDS:
        c = case_index[cid]
        domain = c["domain"]
        row = next(r for r in original if r["slotId"] == c["slotId"])
        group = winner_domain[domain]
        status = {"caseId": cid, "domain": domain, "slotId": c["slotId"]}
        for metric, key in (("selection", "selectionUtility"), ("test", "testUtility")):
            peers = [r for r in group if r["slotId"] != c["slotId"]]
            status[metric + "Higher29"] = sum(r[key] > c[key] + TOL for r in peers)
            status[metric + "Equal29"] = sum(abs(r[key] - c[key]) <= TOL for r in peers)
            status[metric + "Lower29"] = sum(r[key] < c[key] - TOL for r in peers)
            status[metric + "Rank30"] = row[metric + "Rank30"]
            status[metric + "Pareto"] = row[metric + "Pareto"]
            status[metric + "DominatorCount"] = row[metric + "DominatorCount"]
            status[metric + "DominatorIds"] = row[metric + "DominatorIds"]
        status.update(positions(by_domain[domain], c))
        representative = selection_representative(row["selectionDominatorIds"], group)
        status["selectionDominatorRepresentativeId"] = representative["slotId"] if representative else None
        status["selectionDominatorRepresentativeRule"] = "Lexicographically lowest slotId among selection Pareto dominators; fixed without test outcomes" if representative else None
        status["representativeSelectionUtilityDifference"] = representative["selectionUtility"] - c["selectionUtility"] if representative else None
        status["representativeTestUtilityDifference"] = representative["testUtility"] - c["testUtility"] if representative else None
        case_status.append(status)
        left = sessions[c["sessionId"]]["selectedPolicy"]
        trace_cache[c["sessionId"]] = seed_map(left, cid)
        for comparator_type, other in [("reference", c)] + [("original_winner", r) for r in sorted(group, key=lambda r: (r["block"], r["condition"]))]:
            sid = other["sessionId"]
            if sid not in trace_cache:
                trace_cache[sid] = seed_map(sessions[sid]["selectedPolicy"], sid)
            margins = paired_margins(trace_cache[c["sessionId"]], trace_cache[sid], comparator_type == "reference")
            comparisons.append({
                "caseId": cid, "domain": domain, "caseSessionId": c["sessionId"], "caseSlotId": c["slotId"],
                "comparatorType": comparator_type,
                "comparatorCondition": "reference" if comparator_type == "reference" else other["condition"],
                "comparatorBlock": "" if comparator_type == "reference" else other["block"],
                "comparatorSessionId": "" if comparator_type == "reference" else sid,
                "comparatorSlotId": "" if comparator_type == "reference" else other["slotId"],
                "selfComparison": comparator_type == "original_winner" and sid == c["sessionId"],
                **summarize(margins),
            })
    condition_summary = []
    for domain in sorted(winner_domain):
        for condition in sorted({r["condition"] for r in winner_domain[domain]}):
            subset = [r for r in original if r["domain"] == domain and r["condition"] == condition]
            condition_summary.append({
                "domain": domain, "condition": condition, "winnerCount": len(subset),
                "selectionParetoCount": sum(r["selectionPareto"] for r in subset),
                "testParetoCount": sum(r["testPareto"] for r in subset),
                "meanSelectionRank30": statistics.mean(r["selectionRank30"] for r in subset),
                "meanTestRank30": statistics.mean(r["testRank30"] for r in subset),
                "uniqueExactWinnerStrings": len({r["expr"] for r in subset}),
            })
    if len(comparisons) != 62 or len(original) != 90 or len(case_positions) != 90:
        raise ValueError("unexpected result counts")
    return {"definitions": {
        "scope": "Fixed original winners only for primary 30-policy ranks/Pareto; domain-local saved 360 submissions for bounded secondary positions.",
        "crossBlockComparison": "Descriptive comparison of fixed saved test outputs on identical seed identifiers, not a paired generation treatment effect.",
        "testUse": "Test utility describes saved outcomes; no policy is newly selected using test utility.",
        "tolerance": TOL,
        "rank": "Competition rank = 1 + number strictly higher by >1e-12; duplicate occurrences retained.",
        "pareto": "Maximize utility and minimize nodes; both coordinates no worse within tolerance and at least one strict by >tolerance.",
        "exactString": "Literal expr equality with no normalization; duplicate submissions remain separate instances.",
        "p05Margin": "Linear interpolation at (600-1)*0.05 in sorted margins.",
        "worst30MeanMargin": "Observed mean of lowest 30 of 600 margins (bottom 5%); no VaR or population estimate.",
        "gainLoss": "All strictly positive/negative margins contribute, including magnitudes within tie tolerance; gainContribution = positive sum / 600, lossContribution = absolute negative sum / 600. Win/tie/loss counts use tolerance separately.",
        "nullConditional": "Conditional mean is null when no margins of that sign exist.",
    }, "counts": {"catalogOccurrences": 1080, "originalWinners": 90, "comparisons": 62,
                    "domainSubmissionInstances": {d: len(v) for d, v in sorted(by_domain.items())},
                    "domainUniqueExactStrings": {d: len({r["expr"] for r in v}) for d, v in sorted(by_domain.items())},
                    "domainTestedInstances": {d: sum(r["testUtility"] is not None for r in v) for d, v in sorted(by_domain.items())}},
            "cases": case_status, "conditionSummary": condition_summary,
            "originalWinners": original, "casePositions": case_positions,
            "comparisons": comparisons}


def write_csv(path, rows):
    if not rows:
        raise ValueError("cannot write empty CSV")
    with Path(path).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: ";".join(map(str, v)) if isinstance(v, list) else v for k, v in row.items()})


def report(e):
    lines = ["# 저장된 대안 분석", "", "A1·A2의 원래 정책을 고정하고, 각자의 도메인에 있는 원래 선택 정책 30개와 비교했다. 원래 90개 선택 정책 전체의 순위와 Pareto 상태도 기록했다. 새 모델 호출, 평가, 시뮬레이션, 난수 및 유의성 검정은 없다.", "", "선택 효용과 저장된 테스트 효용의 순위는 별도로 계산했다. 테스트 결과로 새 정책을 선택하지 않았다. 블록 간 600개 공통 시드 비교는 이미 저장된 결과의 기술적 비교이며 생성 처리 효과가 아니다.", "", "## A1·A2 위치", "", "|사례|도메인|선택 순위/30|테스트 순위/30|선택 Pareto|테스트 Pareto|전체 제출 선택 순위/360|테스트 순위/분모|", "|---|---|---:|---:|---|---|---:|---:|"]
    for c in e["cases"]:
        lines.append(f"|{c['caseId']}|{c['domain']}|{c['selectionRank30']}|{c['testRank30']}|{c['selectionPareto']}|{c['testPareto']}|{c['selectionRank']}/{c['selectionDenominator']}|{c['testRank']}/{c['testDenominator']}|")
    lines += ["", "각 사례의 나머지 29개 원래 선택 정책 대비 높은/동률/낮은 개수와 모든 Pareto 지배 정책 ID는 `evidence.json`에 있다. `original_winners.csv`는 90개 정책의 조건, 블록, 세션, 정확한 표현식, 노드, 깊이, 순위와 지배 관계를 포함한다. 같은 문자열의 제출은 별도 인스턴스로 유지한다.", "", "## 기준식 대비 시드별 원점수 차이", "", "|사례|평균|승/무/패|최악 30개 평균|최대 손실|평균 이득 기여|평균 손실 기여|", "|---|---:|---:|---:|---:|---:|---:|"]
    for cid in CASE_IDS:
        x = next(x for x in e["comparisons"] if x["caseId"] == cid and x["comparatorType"] == "reference")
        lines.append(f"|{cid}|{x['meanMargin']:+.6f}|{x['wins']}/{x['ties']}/{x['losses']}|{x['worst30MeanMargin']:+.6f}|{x['maximumLoss']:.6f}|{x['gainContribution']:.6f}|{x['lossContribution']:.6f}|")
    a1 = next(c for c in e["cases"] if c["caseId"] == "A1")
    rep_id = a1["selectionDominatorRepresentativeId"]
    rep = next(r for r in e["originalWinners"] if r["slotId"] == rep_id)
    comparison = next(x for x in e["comparisons"] if x["caseId"] == "A1" and x["comparatorSlotId"] == rep_id)
    lines += ["", "## A1의 선택 효용 지배 대안", "", f"A1(9노드)은 같은 Network의 7노드 원래 정책 두 개에 선택 및 테스트 Pareto 기준에서 지배된다. 두 정책의 정확한 수식은 `{rep['expr']}`이며, 대표 비교는 테스트 결과를 보지 않고 지배자 ID의 사전식 첫 항목 `{rep_id}`로 고정했다. 선택 효용 차이는 {a1['representativeSelectionUtilityDifference']:+.9g}, 테스트 효용 차이는 {a1['representativeTestUtilityDifference']:+.9g}로 매우 작다.", "", f"대표 정책 대비 A1의 시드별 원점수 차이는 평균 {comparison['meanMargin']:+.9f}, 승/무/패 {comparison['wins']}/{comparison['ties']}/{comparison['losses']}, 최악 30개 평균 {comparison['worst30MeanMargin']:+.9f}, 최대 손실 {comparison['maximumLoss']:.9f}다. 동률은 1e-12 이내이며 작은 수치 차이에서 실질적 우열을 주장하지 않는다.", "", "`all_alternative_comparisons.csv`는 사례당 원래 정책 30개(자기 자신 포함)와 기준식 1개, 총 62개 비교의 600시드 결합 결과를 제공한다. 승·무·패에는 1e-12 허용오차를 쓰고, 이득·손실 분해에는 부호 그대로를 쓴다. 최악 30개 평균은 관측 하위 5% 평균이며 추정 위험지표가 아니다.", "", "## 도메인별 제출 범위", "", "|도메인|제출 인스턴스|정확 문자열 종류|저장 테스트 있음|저장 테스트 없음|", "|---|---:|---:|---:|---:|"]
    for domain in sorted(e["counts"]["domainSubmissionInstances"]):
        count = e["counts"]["domainSubmissionInstances"][domain]
        tested = e["counts"]["domainTestedInstances"][domain]
        lines.append(f"|{domain}|{count}|{e['counts']['domainUniqueExactStrings'][domain]}|{tested}|{count-tested}|")
    lines += ["", "저장 테스트가 없는 제출은 테스트 순위 분모에서만 제외했다. 누락을 실패로 취급하지 않았다. 전체 제출 범위의 순위는 보조적 위치 정보이며 원래 정책 30개 비교와 혼합하지 않았다.", "", "## 원래 선택 정책의 조건별 요약", "", "|도메인|조건|정책|선택 Pareto|테스트 Pareto|평균 선택 순위/30|평균 테스트 순위/30|", "|---|---|---:|---:|---:|---:|---:|"]
    for x in e["conditionSummary"]:
        lines.append(f"|{x['domain']}|{x['condition']}|{x['winnerCount']}|{x['selectionParetoCount']}|{x['testParetoCount']}|{x['meanSelectionRank30']:.2f}|{x['meanTestRank30']:.2f}|")
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--catalog", type=Path, default=ROOT / "outputs/artifact_analysis_v1.3.0/catalog.json")
    parser.add_argument("--cases", type=Path, default=ROOT / "outputs/artifact_analysis_v1.3.0/cases.json")
    parser.add_argument("--final", type=Path, default=ROOT / "outputs/public_supplement/data/final.json")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    evidence = analyze(read_json(args.catalog), read_json(args.cases), read_json(args.final))
    evidence["sourceSha256"] = {"catalog.json": sha256(args.catalog), "cases.json": sha256(args.cases), "final.json": sha256(args.final)}
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "evidence.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    write_csv(args.output / "original_winners.csv", evidence["originalWinners"])
    write_csv(args.output / "all_alternative_comparisons.csv", evidence["comparisons"])
    write_csv(args.output / "case_positions.csv", evidence["casePositions"])
    (args.output / "report.md").write_text(report(evidence), encoding="utf-8")


if __name__ == "__main__":
    main()
