# Saved alternative analysis v1.5.0

Deterministic, read-only analysis of three saved public artifacts. The script uses only Python's standard library and makes no research-model, evaluator, simulator, random-number, or significance-testing calls.

## Reproduce

From the workspace root:

```powershell
python outputs/alternatives_analysis_v1.5.0/analysis.py
python -m unittest discover -s outputs/alternatives_analysis_v1.5.0 -p test_analysis.py
```

The default inputs are `outputs/artifact_analysis_v1.3.0/catalog.json`, `outputs/artifact_analysis_v1.3.0/cases.json`, and `outputs/public_supplement/data/final.json`. The CLI also accepts `--catalog`, `--cases`, `--final`, and `--output`. Source SHA-256 hashes in `evidence.json` identify the input bytes without recording absolute paths.

## Outputs

- `evidence.json`: complete definitions, all 90 original winners, all 62 fixed-case comparisons, A1/A2 positions, and per-condition summaries.
- `original_winners.csv`: one row for each originally selected policy, retaining duplicate exact expressions as separate occurrences.
- `all_alternative_comparisons.csv`: A1 and A2 versus each of their domain's 30 original winners, including self comparisons, plus a saved reference comparison for each case.
- `case_positions.csv`: all 90 original winners' bounded ranks among the 360 submitted instances in their own domain. Missing saved test values are excluded from the test rank denominator and counted separately.
- `report.md`: concise Korean interpretation.

Primary ranks and Pareto sets use the 30 originally selected policies of the same domain. Selection utility and saved test utility are separate axes of reporting; the analysis never chooses a new policy using test outcomes. Cross-block common-seed margins compare fixed saved outputs descriptively. They are not paired generation treatment effects. Utility scales remain within each domain.

Ranks use competition ranking with 1e-12 strict-comparison tolerance. Pareto dominance maximizes utility and minimizes node count with the same tolerance. Expressions are counted by exact string, with no whitespace or semantic normalization. The observed bottom-30 mean of 600 margins is a descriptive bottom-5% summary, not a risk estimate. Win/tie/loss classification uses tolerance, while gain/loss contributions use every strictly signed margin so that their difference reconstructs the mean.

## From downloaded archives

Extract the new ZIP into `alternatives-analysis-v1.5.0/`, the unchanged v1.3 catalogue ZIP into `artifact-analysis-v1.3.0/`, and the original public evidence ZIP into `public-supplement-v1.0.0/`. These are chosen extraction folder names. Run in their parent directory:

```powershell
python alternatives-analysis-v1.5.0/analysis.py --catalog artifact-analysis-v1.3.0/catalog.json --cases artifact-analysis-v1.3.0/cases.json --final public-supplement-v1.0.0/data/final.json --output replay
python -m unittest discover -s alternatives-analysis-v1.5.0 -p test_analysis.py -v
```

The five generated data/report files (`evidence.json`, three CSV files, `report.md`) reproduce byte-for-byte on the recorded platform. Input hashes are included. CSV line endings follow the CSV writer's dialect; JSON/Markdown use the platform's default newline behavior. No external Python packages or network calls are required by analysis.py.
