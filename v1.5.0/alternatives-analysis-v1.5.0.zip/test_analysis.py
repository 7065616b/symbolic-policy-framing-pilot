import math
import unittest

from analysis import competition_rank, pareto, seed_map, paired_margins, summarize, positions, selection_representative


class AnalysisTests(unittest.TestCase):
    def test_competition_rank_keeps_near_ties_and_duplicate_occurrences(self):
        self.assertEqual(competition_rank(1.0, [1.2, 1.2, 1.0 + 5e-13, 0.8]), 3)

    def test_pareto_counts_all_strict_dominators_but_not_identical_rows(self):
        rows = [
            {"slotId": "a", "nodes": 3, "selectionUtility": 2.0},
            {"slotId": "b", "nodes": 3, "selectionUtility": 2.0},
            {"slotId": "c", "nodes": 4, "selectionUtility": 1.0},
            {"slotId": "d", "nodes": 2, "selectionUtility": 1.0},
        ]
        got = pareto(rows, "selectionUtility")
        self.assertEqual(got["a"], [])
        self.assertEqual(got["b"], [])
        self.assertEqual(got["c"], ["a", "b", "d"])
        self.assertEqual(got["d"], [])

    def test_seed_join_shuffled_and_rejects_missing_duplicate_reference_mismatch(self):
        a = {"perSeed": [{"seed": i, "raw": 2.0, "referenceRaw": 1.0} for i in range(600)], "meanRaw": 2.0, "referenceMeanRaw": 1.0}
        b = {"perSeed": list(reversed([{"seed": i, "raw": 1.0, "referenceRaw": 1.0} for i in range(600)])), "meanRaw": 1.0, "referenceMeanRaw": 1.0}
        self.assertEqual(paired_margins(seed_map(a, "a"), seed_map(b, "b")), [1.0] * 600)
        b["perSeed"][0]["seed"] = 0
        with self.assertRaises(ValueError):
            seed_map(b, "duplicate")
        b["perSeed"] = b["perSeed"][:-1]
        with self.assertRaises(ValueError):
            seed_map(b, "missing")
        b = {"perSeed": [{"seed": i, "raw": 1.0, "referenceRaw": 1.0} for i in range(600)], "meanRaw": 1.0, "referenceMeanRaw": 1.0}
        b["perSeed"][0]["referenceRaw"] = 1.1
        b["referenceMeanRaw"] = 1.1 / 600 + 599 / 600
        with self.assertRaises(ValueError):
            paired_margins(seed_map(a, "a"), seed_map(b, "b"))

    def test_gain_loss_decomposition_and_no_losses(self):
        mixed = summarize([2.0] * 300 + [-1.0] * 300)
        self.assertEqual((mixed["wins"], mixed["ties"], mixed["losses"]), (300, 0, 300))
        self.assertAlmostEqual(mixed["meanMargin"], mixed["gainContribution"] - mixed["lossContribution"])
        self.assertEqual(mixed["meanPositiveGain"], 2.0)
        self.assertEqual(mixed["meanAbsoluteNegativeLoss"], 1.0)
        self.assertEqual(mixed["worst30MeanMargin"], -1.0)
        only_gain = summarize([1.0] * 600)
        self.assertIsNone(only_gain["meanAbsoluteNegativeLoss"])
        self.assertEqual(only_gain["lossContribution"], 0.0)

    def test_secondary_scope_excludes_missing_test_values_and_keeps_duplicates(self):
        rows = [
            {"slotId": "a", "expr": "x", "selectionUtility": 2.0, "testUtility": 1.0},
            {"slotId": "b", "expr": "x", "selectionUtility": 2.0, "testUtility": None},
            {"slotId": "c", "expr": "y", "selectionUtility": 1.0, "testUtility": 2.0},
        ]
        got = positions(rows, rows[0])
        self.assertEqual(got["selectionRank"], 1)
        self.assertEqual(got["selectionDenominator"], 3)
        self.assertEqual(got["testRank"], 2)
        self.assertEqual(got["testDenominator"], 2)
        self.assertEqual(got["uniqueExactStrings"], 2)
        self.assertEqual(got["testedCount"], 2)
        self.assertEqual(got["untestedCount"], 1)

    def test_representative_uses_only_selection_dominators_and_id_order(self):
        rows = [
            {"slotId": "z", "selectionUtility": 2.0, "testUtility": 100.0},
            {"slotId": "a", "selectionUtility": 2.0, "testUtility": 0.0},
        ]
        self.assertEqual(selection_representative(["z", "a"], rows)["slotId"], "a")


if __name__ == "__main__":
    unittest.main()
