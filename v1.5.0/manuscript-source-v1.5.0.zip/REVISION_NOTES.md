# v1.5.0 revision

Expanded from matched examples to the complete original-winner set: 90 policies audited by task, A1/A2 compared with their 30 same-task original winners and reference (62 comparisons). Secondary ranks among 360 submissions retain 327/306 saved test denominators and missing values. Duplicates remain session outcomes; ranks are not counts of independent inventions.

A1 ranks fifth, and two instances of a single seven-node neutral rule have slightly higher selection/test means. The paired rewards tie on 569 of 600 seeds; author judgment shifts from general first priority to an explanatory artifact with a smaller available alternative. A2 ranks first but loses to the smaller cubic alternative on 210 seeds. Mean, signed gain/loss contributions and observed downside are reported without a practical acceptance threshold or population-risk claim.

All original aggregate values and the other fixed cases remain. Earlier A3/A4/A5 paired values are retained in prose and the v1.4 archive. Definitions precede the comparisons; repeated generic caveats are consolidated, with source perspectives, supplied hints, synthetic tasks and retrospective selection kept explicit. Figure/table numbering updates are editorial only. No source-domain causation, isolated term effect, real-world utility, runtime advantage or new optimum is claimed.
