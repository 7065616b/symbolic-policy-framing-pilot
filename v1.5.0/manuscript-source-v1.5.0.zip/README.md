# Submission materials v1.5.0

Cross-Domain Skill Composition: Minimum Coupling and Cubic Stress in Generated Policies

The fixed A1/A2 artifacts are compared with all 30 original winners in their own task, plus bounded ranks among all 360 submitted occurrences. A1's smaller neutral alternative changes the earlier priority judgment; A2's highest observed mean is reported alongside its complexity and observed losses. Early definitions and consolidated common limits make the narrative easier to follow.

`main.pdf` has 7 body pages, one reference page and one summary page (9 total). The official `kaia.cls`, default font size and margins are unchanged. Compile `main.tex` in this folder with `tectonic -X compile main.tex`; a working TeX bundle/cache is needed. `easychair_korean_abstract.md` matches the English title.

Table 1: all five cases and judgments. Table 2: same-task ranks/size-reward positions and test coverage. Table 3: mean gains and observed losses. Tables 4-5: inputs. Table 6 and Figure 3: original aggregate outcomes. Figure 1 illustrates formula behavior; Figure 2 plots every original winner from the focal tasks, with overlapping duplicate instances retained.

Public repository: https://github.com/7065616b/symbolic-policy-framing-pilot, versioned files in `v1.5.0/`. No new research model calls, environment traces, statistical simulations or conference submission. Earlier versions and original records remain unchanged.
