'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {analyzeAll,analyzePair,signOf}=require('./analyze_all.cjs');
const {makeObserved,loadFrozen}=require('./replay.cjs');
const {analyzeAndCompileCandidate}=require('./vendor/ast_evaluator.js');
let result;
test.before(()=>{result=analyzeAll(__dirname);});
test('all 1800 comparisons account for unchanged 2400 policy-seed rewards',()=>{
 assert.equal(result.rows.length,1800);assert.equal(result.verification.policySeedPairs,2400);
 assert.equal(result.verification.referenceSeeds,600);assert.equal(result.verification.maxSavedError,0);assert.equal(result.verification.maxObserverError,0);
 for(const r of result.rows)assert(Math.abs(r.hazardCredit+r.unnecessaryPenalty+r.packPenalty+r.floorAdjustment-r.traceMeanMargin)<1e-12);
});
test('all-seed transition tables, component signs and conditional summaries conserve denominators',()=>{
 for(const s of result.summary){
  assert.equal(s.seeds,600);
  assert.equal(Object.values(s.signMatrix).reduce((n,row)=>n+Object.values(row).reduce((a,b)=>a+b,0),0)+s.noDivergence,600);
  assert.equal(s.finalSigns.positive+s.finalSigns.tie+s.finalSigns.negative,600);
  assert.equal(Object.values(s.largestAbsoluteComponent).reduce((a,b)=>a+b,0),600);
  for(const c of Object.values(s.componentSigns))assert.equal(c.positive+c.tie+c.negative,600);
 }
});
test('every first difference starts in an equal state and obeys the algebraic switch identity',()=>{
 for(const d of result.firstDifferences){
  assert(d.step>=1&&d.step<=320);assert.notEqual(d.a2Action,d.alternativeAction);
  assert(d.a2ScoreGap>=-1e-12&&d.alternativeScoreGap<=1e-12);
  assert(Math.abs(d.a2ScoreGap-d.alternativeScoreGap-d.extraTermGap)<1e-12);
 }
});
test('no-divergence and tolerance boundaries are explicit rather than lost',()=>{
 const {frozen}=loadFrozen(__dirname);const p=frozen.policies[0];const f=analyzeAndCompileCandidate(p.expr,['temp','soc','imped','stress']).fn;
 const rows=[];makeObserved(r=>rows.push(r))(f,1200001,320);
 const r=analyzePair('S',1200001,rows,rows,0);
 assert.equal(r.first,null);assert.equal(r.row.firstStep,null);assert.equal(r.row.traceMeanMargin,0);
 assert.equal(r.row.actionDifferences,0);
 assert.equal(signOf(1e-12),'tie');assert.equal(signOf(-1e-12),'tie');assert.equal(signOf(2e-12),'positive');assert.equal(signOf(-2e-12),'negative');
});
test('previously published six examples remain consistent with all-seed diagnostics',()=>{
 const cases=[['S',1200003,25,0.004217595831758736,0.02021490082179067],['S',1200001,30,-0.00586080010256862,-0.09150064944871039],['N',1200001,15,0.0010621659832497077,-0.007360024651606123],['N',1200004,26,-0.003096390258266579,-0.0015456969540014187],['C',1200003,25,0.0026680219212567025,0.02021490082179067],['C',1200001,30,-0.005728355141647601,-0.09150064944871039]];
 for(const [key,seed,step,mean,instant] of cases){const r=result.rows.find(r=>r.comparator===key&&r.seed===seed);assert.equal(r.firstStep,step);assert.equal(r.traceMeanMargin,mean);assert.equal(r.firstImmediateMargin,instant);}
});
