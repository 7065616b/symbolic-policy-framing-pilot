# A2: all 600 original seeds, v1.9.0

This portable local analysis uses no network, LLM, new policy search or new seeds. Node.js built-in modules are sufficient for the audit. From this directory:

```sh
node --test test_all_seeds.cjs test_replay.cjs
node analyze_all.cjs --out reproduced
node replay.cjs --out reproduced_illustrations
```

The first command runs 12 tests. The second reproduces the four files in results/ byte for byte. The third regenerates the six v1.8 sign-conditioned illustrations and prior comparisons; those are examples, not representative samples. Existing v1.8 full traces remain public. `manifest.json` pins the unchanged original inputs and simulator/AST sources; its illustration rule belongs to v1.8. `analysis_protocol.json` records the additional all-seed diagnostic definitions before inspecting their aggregate outputs, not a prospective preregistration of this retrospective study.

`per_seed_diagnostics.csv` has 1,800 rows, one for each comparator/base-seed pair. `first_divergences.json` stores all four common raw/normalized inputs, both score vectors, zero-based selected indices, one-based step, score gaps and immediate reward components. No-divergence cases would have null first-step CSV fields and no JSON record; none occur. All signs use 1e-12. Exact argmax ties still use the original first-index rule. `largestAbsoluteComponent` is the largest magnitude signed-accounting contribution, not a causal driver; ties and all-zero cases have explicit labels.

`summary.json` contains full 3x3 sign matrices, means, gain/loss/tie-conditioned means, component signs and largest-magnitude counts. Empty subsets have null means. Each matrix sums to 600, not 600 independent LLM generations. `verification.json` confirms all 2,400 saved policy-seed rewards and 600 references exactly, identical first-divergence states, switching identities, and component conservation. Raw-state reward and normalized-state policy scores are intentionally distinct.

Optional figure reproduction requires Python, NumPy and Matplotlib (see requirements-plot.txt): `python plot.py --out figures`. This reads summary.json only. PDF bytes can include creation timestamps; plotted counts and PNGs are deterministic in the same runtime. The main-paper Figure 1 is preserved from v1.8, whose plotting data are also included here.

No additional independent observations or practical validation are supplied. See report_ko.md for interpretation and limits.
