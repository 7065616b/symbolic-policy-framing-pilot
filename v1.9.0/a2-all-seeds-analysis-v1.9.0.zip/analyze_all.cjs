'use strict';
// Fixed-policy diagnostics on original seeds. No network or model dependency.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {loadFrozen,makeObserved}=require('./replay.cjs');
const {DOMAIN_SCI}=require('./vendor/simulators.js');
const {analyzeAndCompileCandidate}=require('./vendor/ast_evaluator.js');
const EPS=1e-12,COMPONENTS=['hazardCredit','unnecessaryPenalty','packPenalty','floorAdjustment'];
const SIGNS=['positive','tie','negative'];
const mean=xs=>xs.length?xs.reduce((a,b)=>a+b,0)/xs.length:null;
const signOf=x=>x>EPS?'positive':x< -EPS?'negative':'tie';
const countSigns=xs=>Object.fromEntries(SIGNS.map(s=>[s,xs.filter(x=>signOf(x)===s).length]));
function extraTerm(key,s){
 if(key==='S')return 0.5*s.soc*s.imped;
 if(key==='C')return 0.4*s.soc*s.imped;
 if(key==='N')return s.stress*s.stress*s.stress-1.5*Math.max(s.stress-0.5,0);
 throw Error('unknown comparator');
}
function analyzePair(key,seed,a,b,traceMeanMargin){
 assert.equal(a.length,320);assert.equal(b.length,320);
 const diffMean=k=>mean(a.map((r,i)=>r[k]-b[i][k]));
 const floor=r=>r.stepReward-(0.50+0.42*r.hazardMitigated-r.unnecessaryDerateLoss-0.14*r.packHazard);
 const components={hazardCredit:0.42*diffMean('hazardMitigated'),unnecessaryPenalty:-diffMean('unnecessaryDerateLoss'),packPenalty:-0.14*diffMean('packHazard'),floorAdjustment:mean(a.map((r,i)=>floor(r)-floor(b[i])))};
 const accountingResidual=Object.values(components).reduce((x,y)=>x+y,0)-traceMeanMargin;
 assert(Math.abs(accountingResidual)<EPS,'accounting residual');
 const i=a.findIndex((r,i)=>r.action!==b[i].action);let first=null;
 if(i>=0){
  const x=a[i],y=b[i],ia=x.action,ib=y.action;
  assert.deepEqual(x.rawStates,y.rawStates,'first-divergence state mismatch');
  const a2ScoreGap=x.scores[ia]-x.scores[ib],alternativeScoreGap=y.scores[ia]-y.scores[ib];
  const extraTermGap=extraTerm(key,x.states[ia])-extraTerm(key,x.states[ib]);
  assert(a2ScoreGap>=-EPS&&alternativeScoreGap<=EPS,'argmax gap inconsistent');
  assert(Math.abs(a2ScoreGap-alternativeScoreGap-extraTermGap)<EPS,'switch identity');
  const selectedRewards=r=>Object.fromEntries(['hazardMitigated','unnecessaryDerateLoss','packHazard','stepReward'].map(k=>[k,r[k]]));
  first={comparator:key,seed,step:x.step,a2Action:ia,alternativeAction:ib,rawStates:x.rawStates,states:x.states,a2Scores:x.scores,alternativeScores:y.scores,
   a2ScoreGap,alternativeScoreGap,extraTermGap,strictSwitch:a2ScoreGap>EPS&&alternativeScoreGap< -EPS,
   immediateMargin:x.stepReward-y.stepReward,a2Reward:selectedRewards(x),alternativeReward:selectedRewards(y)};
 }else assert(Math.abs(traceMeanMargin)<=EPS,'identical actions with nonzero trace margin');
 const ordered=COMPONENTS.map(k=>[k,Math.abs(components[k])]).sort((a,b)=>b[1]-a[1]);
 const largestAbsoluteComponent=ordered[0][1]<=EPS?'none':ordered[0][1]-ordered[1][1]<=EPS?'tie':ordered[0][0];
 const row={comparator:key,seed,traceMeanMargin,finalSign:signOf(traceMeanMargin),...components,accountingResidual,
  largestAbsoluteComponent,actionDifferences:a.filter((r,i)=>r.action!==b[i].action).length,
  firstStep:first?.step??null,firstImmediateMargin:first?.immediateMargin??null,firstSign:first?signOf(first.immediateMargin):'none',
  oppositeSigns:first?first.immediateMargin*traceMeanMargin<0&&signOf(first.immediateMargin)!=='tie'&&signOf(traceMeanMargin)!=='tie':false,
  strictSwitch:first?.strictSwitch??null};
 return {row,first};
}
function summarize(key,rows){
 const r=rows.filter(r=>r.comparator===key),div=r.filter(r=>r.firstStep!==null);
 const steps=div.map(r=>r.firstStep).sort((a,b)=>a-b);
 const componentMeans=Object.fromEntries(COMPONENTS.map(k=>[k,mean(r.map(x=>x[k]))]));
 const conditional=Object.fromEntries(SIGNS.map(s=>{const rr=r.filter(r=>r.finalSign===s);return [s,{n:rr.length,meanMargin:mean(rr.map(r=>r.traceMeanMargin)),components:Object.fromEntries(COMPONENTS.map(k=>[k,mean(rr.map(r=>r[k]))]))}];}));
 return {comparator:key,seeds:r.length,divergenceCount:div.length,noDivergence:r.length-div.length,finalSigns:countSigns(r.map(r=>r.traceMeanMargin)),
  signMatrix:Object.fromEntries(SIGNS.map(s=>[s,Object.fromEntries(SIGNS.map(t=>[t,div.filter(r=>r.firstSign===s&&r.finalSign===t).length]))])),
  oppositeSigns:r.filter(r=>r.oppositeSigns).length,firstLossFinalGain:div.filter(r=>r.firstSign==='negative'&&r.finalSign==='positive').length,
  firstGainFinalLoss:div.filter(r=>r.firstSign==='positive'&&r.finalSign==='negative').length,
  firstStep:steps.length?{min:steps[0],median:(steps[Math.floor((steps.length-1)/2)]+steps[Math.ceil((steps.length-1)/2)])/2,max:steps.at(-1)}:null,
  strictSwitches:div.filter(r=>r.strictSwitch).length,nearTieSwitches:div.filter(r=>!r.strictSwitch).length,
  meanMargin:mean(r.map(r=>r.traceMeanMargin)),componentMeans,conditional,
  componentSigns:Object.fromEntries(COMPONENTS.map(k=>[k,countSigns(r.map(r=>r[k]))])),
  largestAbsoluteComponent:Object.fromEntries([...COMPONENTS,'tie','none'].map(k=>[k,r.filter(r=>r.largestAbsoluteComponent===k).length]))};
}
function analyzeAll(root){
 const {frozen}=loadFrozen(root);assert.deepEqual(frozen.baseSeeds,Array.from({length:600},(_,i)=>1200001+i));assert.equal(frozen.steps,320);
 const functions=new Map(frozen.policies.map(p=>[p.key,analyzeAndCompileCandidate(p.expr,DOMAIN_SCI.vars).fn]));
 const saved=new Map(frozen.policies.map(p=>[p.key,new Map(p.perSeed.map(x=>[x.seed,x]))]));
 let current=[];const observed=makeObserved(r=>current.push(r));const rows=[],firstDifferences=[];let maxSavedError=0,maxObserverError=0,floorClippedSteps=0;
 for(const seed of frozen.baseSeeds){
  const traces=new Map(),reference=DOMAIN_SCI.simulateTrace(DOMAIN_SCI.baselines['PID-lite'],seed,320);
  for(const p of frozen.policies){
   current=[];const replay=observed(functions.get(p.key),seed,320);const original=DOMAIN_SCI.simulateTrace(functions.get(p.key),seed,320),expected=saved.get(p.key).get(seed);
   maxSavedError=Math.max(maxSavedError,Math.abs(replay-expected.raw));maxObserverError=Math.max(maxObserverError,Math.abs(replay-original));
   assert.equal(replay,expected.raw,'saved mean mismatch');assert.equal(replay,original,'instrumentation mismatch');assert.equal(reference,expected.referenceRaw);
   floorClippedSteps+=current.filter(r=>0.50+0.42*r.hazardMitigated-r.unnecessaryDerateLoss-0.14*r.packHazard<0.05).length;
   traces.set(p.key,current);
  }
  for(const key of ['S','N','C']){const r=analyzePair(key,seed,traces.get('A2'),traces.get(key),saved.get('A2').get(seed).raw-saved.get(key).get(seed).raw);rows.push(r.row);if(r.first)firstDifferences.push(r.first);}
 }
 const summary=['S','N','C'].map(k=>summarize(k,rows));
 const verification={result:'PASS',policySeedPairs:2400,referenceSeeds:600,comparisonSeedPairs:1800,maxSavedError,maxObserverError,
  maxAccountingResidual:Math.max(...rows.map(r=>Math.abs(r.accountingResidual))),firstDifferenceRecords:firstDifferences.length,
  firstStatesIdentical:true,switchIdentitiesVerified:true,policySteps:2400*320,floorClippedSteps,newModelCalls:0,newSeeds:0,newIndependentObservations:0,
  analysisProtocolSha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'analysis_protocol.json'))).digest('hex')};
 return {rows,firstDifferences,summary,verification};
}
function writeResults(out,result){
 fs.mkdirSync(out,{recursive:true});
 for(const [name,value] of [['summary.json',result.summary],['first_divergences.json',result.firstDifferences],['verification.json',result.verification]])fs.writeFileSync(path.join(out,name),JSON.stringify(value,null,2)+'\n');
 const headers=Object.keys(result.rows[0]);fs.writeFileSync(path.join(out,'per_seed_diagnostics.csv'),headers.join(',')+'\n'+result.rows.map(r=>headers.map(k=>r[k]??'').join(',')).join('\n')+'\n');
}
if(require.main===module){const args=process.argv.slice(2);assert(args.length===0||(args.length===2&&args[0]==='--out'));const r=analyzeAll(__dirname);writeResults(args[1]??path.join(__dirname,'results'),r);console.log(JSON.stringify({verification:r.verification,summary:r.summary},null,2));}
module.exports={analyzeAll,analyzePair,signOf,summarize,writeResults};
