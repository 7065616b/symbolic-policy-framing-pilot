from pathlib import Path
import json,argparse
args=argparse.ArgumentParser();args.add_argument('--out',default='figures');args=args.parse_args()
dest=Path(args.out);dest.mkdir(parents=True,exist_ok=True)
data=json.loads((Path(__file__).resolve().parent/'results/summary.json').read_text())
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
fig,axes=plt.subplots(1,3,figsize=(8.2,2.7),layout='constrained')
signs=['positive','tie','negative'];labels=['Gain','Tie','Loss']
for ax,d in zip(axes,data):
 mat=np.array([[d['signMatrix'][a][b] for b in signs] for a in signs])
 ax.imshow(mat,cmap='Blues',vmin=0,vmax=300)
 for i in range(3):
  for j in range(3):ax.text(j,i,str(mat[i,j]),ha='center',va='center',fontsize=11,color='white' if mat[i,j]>170 else '#122333')
 ax.set_xticks(range(3),labels);ax.set_yticks(range(3),labels)
 ax.set_xlabel('Full-path mean margin');ax.set_title(f"A2 minus {d['comparator']}  (n=600)\nOpposite signs: {d['oppositeSigns']}/600",fontsize=10)
 ax.tick_params(length=0)
axes[0].set_ylabel('First-action margin')
for ext in ['png','pdf']:fig.savefig(dest/f'all_seed_signs.{ext}',dpi=200,metadata={'Creator':'Local fixed-data analysis'} if ext=='pdf' else None)
plt.close(fig)
