# Submission materials v1.9.0

Cross-Domain Skill Composition: An Exploratory Study of Generated Policies

Eight body pages, one references page and one required summary page; eight tables, three figures. Official class, font defaults and margins are unchanged. Compile main.tex with Tectonic and an available TeX bundle.

All 600 original seeds now receive signed reward accounting and first-action diagnostics against three fixed nearby alternatives. The manuscript distinguishes normalized scores, raw-state rewards, immediate margins and full-path margins. Prior illustrative trajectories and the five case IDs remain; the old winner scatter is retained in previous releases. No new model calls, seeds, policies or independent observations. Original aggregate contrasts and cross-domain/physical limitations remain.
