# v1.9.0 changes

- Table 2: A2/S/N/C expressions, sizes and both saved utilities in one comparison.
- Section 2.1: selection switching inequality, raw-state reward definition and signed accounting.
- Section 2.2 / Table 4 / Figure 2: all 600 seeds, component means and complete immediate/final sign matrices.
- Previous rank table is condensed into prose, retaining every rank/coverage number; its scatter remains in earlier releases. A1's invented arithmetic is condensed to its decision mechanism; the real A2 examples remain.
- Abstract, conclusion and required summary align with these descriptive findings. Five cases, original aggregate results and limitations are preserved.
