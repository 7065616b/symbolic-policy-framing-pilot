# Final submission materials v1.10.2

Cross-Domain Skill Composition: An Exploratory Study of Generated Policies

Use main.pdf for conference submission. The matching English title and Korean submission abstract are in easychair_korean_abstract.md. The files are prepared for submission; the conference submission has not been performed.

This editorial revision makes the introduction, case analysis, methods and summary easier to read. It shortens repetitive explanations, uses active subjects and explains the priority rules before their technical details. Numerical results, tables, equations, figures, references and scientific limitations are preserved from v1.10.1. No new model calls, simulations, experiments or analyses were run.

The official class, font defaults and margins are unchanged. Compile main.tex from this folder with Tectonic and an available TeX bundle. Compilation reads saved manuscript text and figures only.

Verified layout: eight body pages, one references page and one required summary page (ten total); eight tables and three figures. See SUBMISSION_CHECKLIST_KO.md for upload steps.
