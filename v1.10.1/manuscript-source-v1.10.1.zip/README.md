# Final submission materials v1.10.1

Cross-Domain Skill Composition: An Exploratory Study of Generated Policies

Use main.pdf for conference submission. The Korean title/abstract file provides the matching EasyChair text. This is the prepared submission version; it has not been submitted to the conference.

The official class, font defaults and margins remain unchanged. Compile main.tex from this folder with Tectonic and an available TeX bundle. Compilation reads saved manuscript text and figures only.

This editorial update clarifies the abstract, replaces revision-history wording with study-method wording, and specifies two illustration pairs per comparator (six total). All analyses and their limitations are unchanged from v1.10.0. The original data and sensitivity analysis remain available in the repository's earlier directories.

Verified layout: eight body pages, one references page and one required summary page (ten total); eight tables and three figures. See SUBMISSION_CHECKLIST_KO.md for the final upload steps.
