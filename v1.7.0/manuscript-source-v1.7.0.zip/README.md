# Submission materials v1.7.0

Cross-Domain Skill Composition: An Exploratory Study of Generated Policies

The manuscript now explicitly presents an exploratory study. A2 is the central candidate for further examination within its synthetic task; A1 illustrates how a broader alternative set weakens an initially favorable judgment. This is an editorial change within the five fixed retrospective cases, not a new test-based selection.

Title, abstract, introduction, conclusion, required summary and Korean abstract use the same scope. A2 appears first in the case narrative and Tables 1, 3 and 4; original case identifiers remain unchanged. All numerical table rows, worked-example values, figures, methods, aggregate evidence and references are preserved.

The PDF has 7 body pages, one references page and one summary page (9 total), with seven tables and three figures. Official class, font defaults and margins remain unchanged. Compile `main.tex` with `tectonic -X compile main.tex` using an available TeX bundle/cache. The source ZIP includes the unchanged `examples/worked_example.py`; `python examples/worked_example.py --output replay.json` reproduces its exact arithmetic without network access.

The worked example uses invented normalized inputs and explains a pairwise choice. It is not an empirical observation or validation of physical thermal behavior. The original catalogue, five cases, v1.5.0 alternative/loss analysis and all evidence remain at https://github.com/7065616b/symbolic-policy-framing-pilot. No new model calls, helper agents, environment evaluations, statistical simulations or conference submission occurred.
