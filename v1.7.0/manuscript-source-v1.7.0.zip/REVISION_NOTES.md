# v1.7.0 editorial revision

- Retitled the paper to explicitly state an exploratory study of generated policies under cross-domain skill composition.
- Put A2 first as the central candidate for further examination, while retaining its smaller comparator, observed losses and practical limitations.
- Present A1 as a case where expanding from the original block to the full same-task winner set changes the adoption judgment.
- Keep the five case IDs and selection rule fixed. Table row order changes are editorial; no policy is newly selected on test results.
- Align abstract, introduction, conclusion, summary, Korean abstract and public reader guide. Preserve the original methods, aggregate evidence, neutral-condition occurrences, input hints and source/target distinction.
- Preserve all numerical table rows, figures and the invented A2 worked example. Original data and analyses remain unchanged.

No new model calls, environment traces or statistical simulations were performed.
