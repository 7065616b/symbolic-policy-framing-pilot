'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {makeGrid,stepReward,scoreTrace,runSensitivity,makeWeightedSimulator}=require('./sensitivity.cjs');
const {loadFrozen}=require('./replay.cjs');
const {DOMAIN_SCI}=require('./vendor/simulators.js');
const {analyzeAndCompileCandidate}=require('./vendor/ast_evaluator.js');
let result;test.before(()=>{result=runSensitivity(__dirname);});
test('fixed grids deduplicate baseline and axis/cube overlap without losing labels',()=>{
 const g=makeGrid();assert.equal(g.length,36);assert.equal(new Set(g.map(x=>x.id)).size,36);
 assert.equal(g.filter(x=>x.inJointCube).length,27);
 for(const k of ['a','b','c'])assert.equal(g.filter(x=>x.axes.includes(k)).length,6);
 assert.equal(g.filter(x=>x.a===1&&x.b===1&&x.c===1).length,1);
});
test('floor is applied to every step before averaging and remains fixed',()=>{
 const rows=[{hazardMitigated:0,unnecessaryDerateLoss:.5,packHazard:1},{hazardMitigated:2,unnecessaryDerateLoss:0,packHazard:0}];
 assert.equal(stepReward(rows[0],{a:1,b:1,c:1}),.05);
 assert(Math.abs(scoreTrace(rows,{a:1,b:1,c:1}).mean-.695)<1e-14);
 assert.equal(scoreTrace(rows,{a:1,b:1,c:1}).clippedSteps,1);
 assert.throws(()=>scoreTrace(rows,{a:-1,b:1,c:1}));
});
test('baseline and every weighted objective match independent direct simulator execution',()=>{
 assert.equal(result.verification.savedPolicySeeds,2400);assert.equal(result.verification.referenceSeeds,600);
 assert.equal(result.verification.maxSavedError,0);assert.equal(result.verification.directWeightedChecks,36*2400);
 assert.equal(result.verification.maxDirectWeightedError,0);
 assert.equal(result.rows.length,36*3*600);
});
test('every summary conserves all seeds and ranks fixed policies without original-reference ratios',()=>{
 for(const s of result.summary){
  assert.equal(s.comparisons.length,3);assert.equal(s.policies.length,4);
  for(const p of s.policies)assert.equal(p.rank,1+s.policies.filter(q=>q.mean>p.mean+1e-12).length);
  for(const c of s.comparisons)assert.equal(c.wins+c.ties+c.losses,600);
  assert.equal(s.policies.find(p=>p.key==='A2').rank,1+s.comparisons.filter(c=>c.meanMargin< -1e-12).length);
 }
 const b=result.summary.find(s=>s.a===1&&s.b===1&&s.c===1);
 assert.deepEqual(b.comparisons.map(c=>[c.wins,c.ties,c.losses]),[[390,0,210],[308,0,292],[342,0,258]]);
});
test('changing the reward cannot change selected actions or random trajectories',()=>{
 const {frozen}=loadFrozen(__dirname);const fn=analyzeAndCompileCandidate(frozen.policies[0].expr,DOMAIN_SCI.vars).fn;
 for(const seed of [1200001,1200600]){
  const original=[];DOMAIN_SCI.simulateTrace(s=>{original.push({...s});return fn(s);},seed,320);
  for(const g of makeGrid()){
   const changed=[];makeWeightedSimulator(g)(s=>{changed.push({...s});return fn(s);},seed,320);
   assert.deepEqual(changed,original);
  }
 }
});
