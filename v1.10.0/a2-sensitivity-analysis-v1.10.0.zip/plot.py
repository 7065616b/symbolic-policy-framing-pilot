"""Plot all prerecord-defined one-at-a-time factors from saved outputs only."""
from pathlib import Path
import json,argparse
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
args=argparse.ArgumentParser();args.add_argument('--out',default='figures');args=args.parse_args()
dest=Path(args.out);dest.mkdir(parents=True,exist_ok=True)
summary=json.loads((Path(__file__).resolve().parent/'results/summary.json').read_text())
colors={'S':'#24658a','N':'#bd5a27','C':'#68579a'}
fig,axs=plt.subplots(1,3,figsize=(8.2,2.6),layout='constrained',sharey=True)
for ax,axis,title in zip(axs,['a','b','c'],['Hazard-credit weight (a)','Action-penalty weight (b)','Pack-penalty weight (c)']):
 rows=sorted([s for s in summary if axis in s['axes']],key=lambda s:s[axis])
 ax.axhline(0,color='#555555',lw=.8);ax.axvline(1,color='#888888',lw=.8,ls=':')
 for comp in ['S','N','C']:
  ax.plot([s[axis] for s in rows],[next(c['meanMargin'] for c in s['comparisons'] if c['comparator']==comp)*1000 for s in rows],marker='o',ms=3.3,label=comp,color=colors[comp],lw=1.4)
 ax.set_title(title,fontsize=10);ax.set_xlabel('Multiplier (others = 1)');ax.set_xticks([.5,1,1.5,2]);ax.spines[['right','top']].set_visible(False)
 ax.tick_params(labelsize=9)
axs[0].set_ylabel('Mean A2 minus alternative\n(raw reward × 1,000)');axs[0].legend(title='Alternative',frameon=False,fontsize=8,title_fontsize=8)
for ext in ['png','pdf']:fig.savefig(dest/f'reward_sensitivity.{ext}',dpi=200,metadata={'Creator':'Fixed-policy saved-seed sensitivity'} if ext=='pdf' else None)
plt.close(fig)
