# A2 reward-weight sensitivity, v1.10.0

Local, deterministic, fixed-policy analysis. No network, model API, new policy, seed or independent observation. Node.js built-in modules suffice:

```sh
node --test test_sensitivity.cjs test_replay.cjs
node sensitivity.cjs --out reproduced
```

The tests include all 36 configurations and direct simulator equivalence. Reproduction takes roughly tens of seconds and regenerates all seven files in results/ byte for byte in the recorded runtime (Node 24.19.0). `manifest.json` pins the unchanged original inputs and simulator/AST files; its six-example rule is inherited from v1.8 and is not the new sensitivity design. `sensitivity_protocol.json` fixes the diagnostic grid before computing the new results, within an already retrospective study. It is not preregistration.

Reward = max(0.05, 0.50 + 0.42*a*h - b*D - 0.14*c*P). Multipliers change only outer coefficients. Floor, constant, inner feature definitions, policy coefficients, actions and transitions stay fixed. Reward is not an input to the frozen policies or transition function. We still verify direct simulation after replacing only the reward line for every policy, seed and configuration. The floor is applied to each step BEFORE averaging. Reweighting the previous aggregate component table without floor correction is generally wrong.

One-at-a-time factors are 0.5,0.75,1,1.25,1.5,2; the other factors stay at 1. The joint cube is all 27 combinations of 0.75,1,1.25. Deduplication gives 36 configurations. These are analyst-chosen diagnostics, not plausible physical intervals or probabilities. No best coefficient is selected and policies are not retrained.

- configurations.json: all factors and overlapping membership labels.
- summary.json: four-policy mean ranks, A2/S,N,C raw margins, 600-seed wins/ties/losses, lowest-30 mean, largest loss, and clipping/floor corrections.
- diagnostic.json: joint-grid counts and extrema; finite grid counts are not robustness probabilities.
- per_seed_margins.csv: 64,800 paired margins (36 configurations × 3 comparators × 600 SAME seeds).
- policy_seed_scores.csv: 86,400 reweighted means, clipped-step counts, and mean floor correction.
- base_components.csv: 2,400 per-policy/seed means of h,D,P; reconstruction requires each configuration's floor correction.
- verification.json: exact baseline reproduction and all direct weighted checks.

All comparisons are raw reward differences, not original-reference U under a changed objective. Signs/ranks use 1e-12; ties stay explicit. Clipped-step counts across configurations reuse trajectories and are not counts of independent physical events. The original reference is checked on 600 seeds at baseline only.

Optional `python plot.py --out figures` needs requirements-plot.txt. It reads summaries only; line segments connect evaluated points, not a continuous guarantee. Same-runtime PNGs are deterministic; PDF metadata may contain timestamps.

source_prompt_A2.json is the exact original A2 prompt; provenance_A2.json separates supplied elements, observed revisions and unestablished source-domain mechanisms. See report_ko.md for the complete interpretation. Earlier v1.9 all-seed diagnostics remain unchanged and public.
