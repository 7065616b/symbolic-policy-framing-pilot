'use strict';
// Fixed trajectories and policies only; no network, model adapter or search.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {loadFrozen,makeObserved}=require('./replay.cjs');
const {DOMAIN_SCI,mulberry32,norm}=require('./vendor/simulators.js');
const {analyzeAndCompileCandidate}=require('./vendor/ast_evaluator.js');
const EPS=1e-12,FACTORS=[.5,.75,1,1.25,1.5,2],JOINT=[.75,1,1.25];
const mean=xs=>xs.reduce((a,b)=>a+b,0)/xs.length;
function makeGrid(){
 const configs=new Map();
 const add=(a,b,c,axis=null,joint=false)=>{const id=`h${a}_d${b}_p${c}`;if(!configs.has(id))configs.set(id,{id,a,b,c,axes:[],inJointCube:false});const x=configs.get(id);if(axis&&!x.axes.includes(axis))x.axes.push(axis);x.inJointCube ||=joint;};
 for(const axis of ['a','b','c'])for(const v of FACTORS){const w={a:1,b:1,c:1};w[axis]=v;add(w.a,w.b,w.c,axis);}
 for(const a of JOINT)for(const b of JOINT)for(const c of JOINT)add(a,b,c,null,true);
 return [...configs.values()];
}
const unfloored=(r,w)=>.50+.42*w.a*r.hazardMitigated-w.b*r.unnecessaryDerateLoss-.14*w.c*r.packHazard;
const stepReward=(r,w)=>Math.max(.05,unfloored(r,w));
function scoreTrace(rows,w){
 for(const k of ['a','b','c'])assert(Number.isFinite(w[k])&&w[k]>=0,'invalid multiplier');
 assert(rows.length>0);let total=0,clippedSteps=0,correction=0;
 for(const r of rows){const u=unfloored(r,w),score=stepReward(r,w);total+=score;if(u<.05)clippedSteps++;correction+=score-u;}
 return {mean:total/rows.length,clippedSteps,floorCorrection:correction/rows.length};
}
function makeWeightedSimulator(w){
 let source=DOMAIN_SCI.simulateTrace.toString().replace('simulateTrace(','function simulateTrace(');
 const anchor='Math.max(0.05, 0.50 + 0.42 * hazardMitigated - unnecessaryDerateLoss - 0.14 * packHazard)';
 assert.equal(source.split(anchor).length,2);
 source=source.replace(anchor,`Math.max(0.05, 0.50 + 0.42 * ${w.a} * hazardMitigated - ${w.b} * unnecessaryDerateLoss - 0.14 * ${w.c} * packHazard)`);
 return new Function('mulberry32','norm','return ('+source+');')(mulberry32,norm);
}
function runSensitivity(root){
 const protocol=JSON.parse(fs.readFileSync(path.join(root,'sensitivity_protocol.json'),'utf8'));
 assert.deepEqual(protocol.oneAtATime,FACTORS);assert.deepEqual(protocol.jointCube,JOINT);
 const {frozen}=loadFrozen(root);assert.deepEqual(frozen.baseSeeds,Array.from({length:600},(_,i)=>1200001+i));assert.equal(frozen.steps,320);
 assert.deepEqual(frozen.policies.map(p=>p.key),['A2','S','N','C']);
 const grid=makeGrid(),base=grid.find(g=>g.a===1&&g.b===1&&g.c===1),compiled=new Map(),saved=new Map();
 for(const p of frozen.policies){const ast=analyzeAndCompileCandidate(p.expr,DOMAIN_SCI.vars);assert(ast.stage1Valid);assert.equal(ast.nodes,p.nodes);assert.equal(ast.depth,p.depth);compiled.set(p.key,ast.fn);assert.deepEqual(p.perSeed.map(r=>r.seed),frozen.baseSeeds);saved.set(p.key,new Map(p.perSeed.map(r=>[r.seed,r])));}
 const direct=new Map(grid.map(g=>[g.id,makeWeightedSimulator(g)]));let current=[];const observed=makeObserved(r=>current.push(r));
 const scores=[],components=[],rows=[];let maxSavedError=0,maxDirectWeightedError=0;
 for(const seed of frozen.baseSeeds){
  const reference=DOMAIN_SCI.simulateTrace(DOMAIN_SCI.baselines['PID-lite'],seed,320),byPolicy=new Map();
  for(const p of frozen.policies){
   current=[];const originalMean=observed(compiled.get(p.key),seed,320),stored=saved.get(p.key).get(seed);
   assert.equal(originalMean,stored.raw);assert.equal(reference,stored.referenceRaw);assert.equal(current.length,320);
   components.push({policy:p.key,seed,hMean:mean(current.map(r=>r.hazardMitigated)),dMean:mean(current.map(r=>r.unnecessaryDerateLoss)),pMean:mean(current.map(r=>r.packHazard))});
   const map=new Map();
   for(const g of grid){
    const scored=scoreTrace(current,g),directMean=direct.get(g.id)(compiled.get(p.key),seed,320);
    maxDirectWeightedError=Math.max(maxDirectWeightedError,Math.abs(scored.mean-directMean));assert.equal(scored.mean,directMean,'weighted replay mismatch');
    if(g.id===base.id){maxSavedError=Math.max(maxSavedError,Math.abs(scored.mean-stored.raw));assert.equal(scored.mean,stored.raw,'baseline mismatch');}
    scores.push({configuration:g.id,policy:p.key,seed,...scored});map.set(g.id,scored.mean);
   }
   byPolicy.set(p.key,map);
  }
  for(const g of grid)for(const key of ['S','N','C'])rows.push({configuration:g.id,comparator:key,seed,margin:byPolicy.get('A2').get(g.id)-byPolicy.get(key).get(g.id)});
 }
 const summary=grid.map(g=>{
  const policies=frozen.policies.map(p=>{const r=scores.filter(x=>x.configuration===g.id&&x.policy===p.key);return {key:p.key,nodes:p.nodes,mean:mean(r.map(x=>x.mean)),clippedSteps:r.reduce((n,x)=>n+x.clippedSteps,0),floorCorrection:mean(r.map(x=>x.floorCorrection))};});
  for(const p of policies)p.rank=1+policies.filter(q=>q.mean>p.mean+EPS).length;
  const comparisons=['S','N','C'].map(key=>{const d=rows.filter(r=>r.configuration===g.id&&r.comparator===key).map(r=>r.margin).sort((a,b)=>a-b);return {comparator:key,meanMargin:mean(d),wins:d.filter(x=>x>EPS).length,ties:d.filter(x=>Math.abs(x)<=EPS).length,losses:d.filter(x=>x< -EPS).length,worst30Mean:mean(d.slice(0,30)),largestLoss:Math.max(0,-d[0])};});
  return {...g,policies,comparisons};
 });
 const joint=summary.filter(g=>g.inJointCube);
 const diagnostic={jointConfigurations:joint.length,a2JointRankCounts:Object.fromEntries([1,2,3,4].map(n=>[n,joint.filter(g=>g.policies[0].rank===n).length])),jointComparisons:['S','N','C'].map(key=>{const m=joint.map(g=>g.comparisons.find(x=>x.comparator===key).meanMargin);return {comparator:key,positive:m.filter(x=>x>EPS).length,tie:m.filter(x=>Math.abs(x)<=EPS).length,negative:m.filter(x=>x< -EPS).length,minMean:Math.min(...m),maxMean:Math.max(...m)};})};
 const verification={result:'PASS',configurations:grid.length,savedPolicySeeds:2400,referenceSeeds:600,directWeightedChecks:scores.length,comparisonRows:rows.length,maxSavedError,maxDirectWeightedError,newModelCalls:0,newPolicies:0,newSeeds:0,newIndependentObservations:0,protocolSha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'sensitivity_protocol.json'))).digest('hex')};
 return {grid,summary,diagnostic,verification,rows,scores,components};
}
function writeResults(out,result){
 fs.mkdirSync(out,{recursive:true});
 for(const [name,data] of [['configurations.json',result.grid],['summary.json',result.summary],['diagnostic.json',result.diagnostic],['verification.json',result.verification]])fs.writeFileSync(path.join(out,name),JSON.stringify(data,null,2)+'\n');
 for(const [name,data] of [['per_seed_margins.csv',result.rows],['policy_seed_scores.csv',result.scores],['base_components.csv',result.components]]){const fields=Object.keys(data[0]);fs.writeFileSync(path.join(out,name),fields.join(',')+'\n'+data.map(r=>fields.map(k=>r[k]).join(',')).join('\n')+'\n');}
}
if(require.main===module){const args=process.argv.slice(2);assert(args.length===0||(args.length===2&&args[0]==='--out'));const r=runSensitivity(__dirname);writeResults(args[1]??path.join(__dirname,'results'),r);console.log(JSON.stringify({verification:r.verification,diagnostic:r.diagnostic},null,2));}
module.exports={makeGrid,stepReward,scoreTrace,makeWeightedSimulator,runSensitivity,writeResults};
