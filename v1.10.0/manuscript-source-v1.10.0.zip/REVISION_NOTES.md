# v1.10.0 changes

- Section 2.1 distinguishes supplied domain/math guidance, recorded formula changes and unknown source mechanisms.
- Section 2.3 and Figure 2 report stepwise reward-weight sensitivity on a fixed grid, including all negative outcomes and clipping.
- Final A2 judgment compares S/N/C and reserves practical adoption; A1 remains the comparator-scope contrast.
- Abstract, introduction, conclusion and summary foreground conditional candidate value. Repeated prose is condensed within the eight-page body limit; all five cases and original aggregate tables remain.
- The v1.9 sign-matrix figure and full diagnostic records remain in that version, unchanged.
