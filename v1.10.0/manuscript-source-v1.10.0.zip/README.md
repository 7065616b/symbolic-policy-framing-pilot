# Submission materials v1.10.0

Cross-Domain Skill Composition: An Exploratory Study of Generated Policies

Eight body pages, one references page and one required summary page; eight tables, three figures. Official class, font defaults and margins remain unchanged. Compile main.tex with Tectonic and an available TeX bundle.

This revision adds 36 fixed reward-weight configurations, preserves original A2/S/N/C trajectories, and explicitly separates supplied elements, generated changes and unestablished source-domain mechanisms. A2 is a conditional follow-up candidate, not a default replacement. Figure 2 replaces the earlier first-action sign heatmap, which remains public in v1.9; its principal counts remain in the manuscript. Original cases, aggregate evidence and limitations remain.

No new model calls, policies or test seeds. Changed-objective scores are not independent observations. All 86,400 scores match direct reward-modified simulation and the 2,400 original rewards remain exact.
