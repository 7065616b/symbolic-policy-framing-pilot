# Cross-Domain Skill Composition: An Exploratory Study of Generated Policies

**Bogyun Kim**  
Department of Computer Engineering, Mokpo National University, Muan, Republic of Korea  
`s11s45@naver.com`

## Abstract

We examine symbolic policies generated under prompt-level composition of biological/HCI exploration and minimalist-design guidance. The contribution is a traceable assessment of what was supplied, what was generated and when a candidate remains worth examining. Among five fixed retrospective cases, A2 combines a supplied interaction with cubic stress and has the highest observed mean among 30 original Thermal winners. Nearby alternatives expose its limits: the strongest selection-ranked neutral winner is two nodes larger, but A2 wins only 308 of 600 saved traces against it. Full-path accounting shows that favorable hazard-credit differences are partly offset by penalties. Rescoring the same trajectories under 36 fixed reward-weight configurations further qualifies the judgment. A2 ranks first among four policies in 22 of 27 joint +/-25% configurations, but loses to the neutral alternative in four; halving hazard-credit weight makes it last among the four. These grid counts are descriptive, not probabilities. A2 is retained as a conditional follow-up candidate, while A1 illustrates how broader comparison weakens an initial preference. Both highlighted structures also occur in neutral conditions, and the original framing contrast remains -0.1111 near-reference components per session. No new model calls, policies or test seeds are added. Cross-domain causation and practical utility remain unresolved.

**Keywords:** Cross-domain skill composition, symbolic policies, exploratory study, candidate evaluation.

## 1. Introduction and Related Work

An interesting generated rule should be something a reader can inspect, explain and compare with an alternative. The possibility of combining perspectives from unrelated domains motivates this work. Our exploratory question is which policies generated under that setting merit further examination when their inputs, alternatives and losses are made explicit. We combine biological immune-adaptation and human-computer interaction (HCI) reframing with minimalist industrial-design guidance. The source domains are named by the prompt; the model chooses expressions within a supplied grammar, task facts, mathematical hints H and feedback. Here skill composition means textual guidance in one prompt, not independently executed agents or unconstrained discovery of source domains.

**X/N** denote cross-domain/neutral wording; **ROLE/FLAT** assign exploration and simplicity separate/combined functions within one prompt. **H** denotes supplied mathematical hints. A **block** contains one session per condition and task; its **original winners** are selected before test access. **Utility U** divides mean reward by the same task's reference mean (U=1). **Nodes** measure expression size, not runtime. Each **trace** is a 320-step synthetic run, not an independent model generation.

The main finding is that candidate value depends on both the alternative and the reward definition. A2 changes rank under reweighted rewards; A1 loses its initial appeal under broader comparison. The five case IDs and original winners remain fixed. This retrospective analysis examines the outputs of cross-domain prompting without treating their presence as evidence of knowledge transfer.

LLM-driven executable search has precedents in FunSearch [1], Evolution of Heuristics [2] and ReEvo [3]. Analogical prompting [10] and cross-domain scientific search [7] motivate source perspectives; CreativeDC [6] combines divergent and convergent instructions. HSEvo [4], Language Model Crossover [5] and MAP-Elites [9] address diversity alongside quality; persona effects are task-dependent [8]. Our contribution is a traceable case study of generated structures and decisions about their value, not a new search or analogy algorithm. An older 414-expression corpus is excluded because its generation requests are unavailable.

## 2. A2 as a Candidate and A1 under Broader Comparison

Table 1 links supplied templates, exact outputs and judgments. A1/A2/A3/A5 use X_ROLE; A4 uses X_FLAT. Source-domain wording guides generation but does not identify the origin of a term.

| Case | Supplied input H | Exact generated expression | Comparison alternative | Author judgment |
| --- | --- | --- | --- | --- |
| A2 | `soc*imped`; `max(stress-0.5,0)`; temperature | `temp+(0.5*(soc*imped)+stress*stress*stress)` | `temp+stress*stress*stress` (X_FLAT; 7 nodes) | Conditional follow-up: favorable original mean; preference changes with reward weights |
| A1 | `queue*(0.45+drift)`; `max(burst-idle,0)`; negative idle | `queue+min(drift,burst)-0.5*idle` | `queue+drift-0.5*idle` (neutral; 7 nodes) | Broader comparison weakens the initial adoption argument; a smaller alternative scores slightly higher |
| A3 | `cost*freq`; `min(freq-0.5,0.25)`; positive jitter with idle | `idle-0.35*min(freq-0.5,0.25)+0.2*jitter` | `idle` (reference) | Low-priority diagnostic: supplied cap and tiny reference margin |
| A4 | Same Thermal H as A2 | `temp+soc*imped+2*max(stress-0.5,0)` | `temp+soc*imped+max(stress-0.5,0)` (matched X_ROLE) | Assembly/control example: supplied terms, with higher size and mean |
| A5 | Same Network H as A1 | `queue*(0.35+drift)-0.25*idle` | `queue+drift-0.5*idle` (matched N_ROLE) | Deprioritize: the smaller alternative scores higher |

*Table 1. Input, exact output, comparison and judgment for all five fixed cases; A2 is presented first and original case IDs are retained. H entries summarize the supplied mathematical hints; the source-domain instruction above, task facts, grammar and session feedback are also inputs. Input-output differences do not identify a biological/HCI mechanism. A1's alternative comes from the full winner set; A2/A4/A5 use matched-block alternatives and A3 uses the reference. These are reasons for further examination or deprioritization, not deployment decisions. Table 2 consolidates A2 and its three nearby alternatives.*

### 2.1 A2: Central Candidate for Further Examination

A2 ranks four synthetic modules for derating; soc is state of charge and imped is impedance. Three evidence levels separate its origin from its value.

**Supplied:** the prompt names biological immune-adaptation, HCI reframing and minimalist design, and gives the four variables, grammar, feedback, temperature term, soc*imped and max(stress-0.5,0). It does not prescribe A2's complete formula.

**Generated:** A2 retains temperature and the product, weights the product by 0.5, omits the supplied threshold and uses cubic stress. Cubing normalized [0,1] stress reduces its value except at the endpoints. The saved sequence contains product weight 1 in round 3 slot 9 and weight 0.5 in round 4 after feedback. These are observed expression changes relative to H and the preceding response.

**Unestablished:** the record does not map a biological/HCI principle to the cubic term, prove a new mathematical idea or reveal the model's reasoning. The cubic motif also occurs under neutral wording. The original topic is therefore examined through generated artifacts and their assessment, not an asserted causal domain transfer.

| Policy | Exact score expression | Nodes | Selection U | Test U |
| --- | --- | ---: | ---: | ---: |
| A2 | `temp+(0.5*(soc*imped)+stress*stress*stress)` | 13 | 1.011889 | 1.011170 |
| S | `temp+stress*stress*stress` | 7 | 1.010594 | 1.009897 |
| N | `temp+0.5*soc*imped+1.5*max(stress-0.5,0)` | 15 | 1.011573 | 1.011015 |
| C | `temp+stress*stress*stress+0.1*soc*imped` | 13 | 1.011253 | 1.010659 |

*Table 2. Fixed nearby policies. S is the matched-block seven-node X_FLAT winner; N is the highest selection-mean neutral Thermal winner (N_FLAT block 6); C is the highest selection-mean other 13-node Thermal winner with the literal cubic motif (X_FLAT block 2). These retrospective choices use original winners and selection data, not a coefficient search. U is a ratio of means, not a raw reward difference; nodes measure size, not speed.*

An observer records inputs, choices and rewards on all 600 original 320-step seeds without changing transitions or random draws. All 2,400 policy-seed means and 600 references exactly match saved values and the original simulator. These are diagnostics of existing observations, not independent tests.

For each alternative, the six illustrations use the smallest base seed with positive A2 margin and the smallest with negative margin (tolerance 1e-12), then inspect the first differing action. This retrospective sign-conditioned rule is not representative sampling. Table 3 shows S comparisons; all four inputs and full trajectories are public.

| Trace / step | Module (chosen by) | temp | soc | imped | stress | S score | A2 score |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Gain / 25 | 3 (A2) | 0.456673 | 0.576453 | 0.224144 | 0.317894 | 0.488798 | 0.553402 |
| Gain / 25 | 4 (S) | 0.461809 | 0.571182 | 0.185761 | 0.308865 | 0.491274 | 0.544326 |
| Loss / 30 | 1 (S) | 0.540988 | 0.593125 | 0.262826 | 0.348180 | 0.583197 | 0.661141 |
| Loss / 30 | 4 (A2) | 0.462533 | 0.613333 | 0.301407 | 0.482664 | 0.574977 | 0.667408 |

*Table 3. Recorded normalized inputs and scores at the first action divergence from S. Gain is base seed 1200003, step 25; loss is seed 1200001, step 30. Steps and modules are one-based. Both policies have identical pre-action states at these points; values are rounded from full precision. The selected module has the highest score among all four modules. Scores are not rewards, and these are synthetic replay states, not physical measurements.*

In the gain trace, the added product moves A2 from S's module 4 to module 3: immediate reward rises from 0.757709 to 0.777924, and the full-trace mean margin is +0.004218. In the loss trace, A2 selects module 4 with higher soc, imped and stress instead of hotter module 1: reward falls from 0.884275 to 0.792774, and the full mean margin is -0.005861. Both examples have zero unnecessary-derating penalty and no floor clipping at that step.

The switching rule is explicit. Let t and x be normalized temperature and stress, p=soc*imped, and B=t+x cubed. For S's selected module b and A2's selected module a, a strict switch requires:

$$0 < B_b-B_a < 0.5(p_a-p_b).$$

The product advantage exceeds S's score disadvantage: 0.011553 versus 0.002476 in the gain example; 0.014487 versus 0.008220 in the loss. The same rule accompanies either outcome. Relative to C, the added score is 0.4*p; relative to N it is x cubed minus 1.5*max(x-0.5,0). In each case the difference of these added terms between a and b must overcome the alternative's score gap. This describes the selected pair; each policy still takes the maximum over all four modules. Exact ties retain the first module.

The reward uses raw states, whereas policy scores use normalized inputs. Write T, Q, I and X for raw temperature, charge, impedance and stress. For the chosen module, the code computes h=T+0.75*Q*I+0.45*max(X-0.95,0) before acting and D=0.50 only when both X<0.85 and T<0.75 (otherwise zero). The action multiplies its T by 0.45 and X by 0.5. Then P sums 0.4*T+0.28*Q*I across all four post-action modules. The step reward is:

$$r=\max(0.05,\;0.50+0.42h-D-0.14P).$$

Here h is a designed credit for selecting a high-index module, not measured heat removal. D penalizes an action on a low-state module; P penalizes remaining pack state. Let F be the amount added by the 0.05 floor. A2-minus-alternative mean reward decomposes exactly into 0.42 times the mean h difference, minus the mean D difference, minus 0.14 times the mean P difference, plus the mean F difference. These are signed accounting contributions along the observed paths, not causal interventions on individual terms or validated thermal protection.

![Replayed choices and cumulative reward differences](images/a2_replay.png)

*Figure 1. Cumulative raw reward differences from deterministic replay of existing test seeds. Dashed lines and dots mark the first differing action. Panels use the stated sign-conditioned rule, not the largest gains/losses. The N trace starts with an immediate loss at divergence but ends positive; the mean margin is the final cumulative difference divided by 320. Later paths may contain different states. All six trace pairs are available in the supplement.*

### 2.2 What All 600 Existing Seeds Show

All 600 saved seeds receive accounting and first-action diagnostics; definitions were frozen before the v1.9 extension, while the study and policy choices remain retrospective. Every A2/S, A2/N and A2/C pair differs in action. First differences occur at median steps 14, 13 and 16 (ranges 1-90, 1-100 and 1-93). All 1,800 have identical pre-action states and strict score-gap identities; there are no near-tie or no-divergence cases.

| A2 minus | Hazard credit | Action penalty | Pack penalty | Floor | Total |
| --- | ---: | ---: | ---: | ---: | ---: |
| S | +0.003572 | -0.000419 | -0.001517 | 0.000000 | +0.001635 |
| N | +0.000750 | -0.000471 | -0.000080 | 0.000000 | +0.000198 |
| C | +0.002263 | -0.000388 | -0.001219 | 0.000000 | +0.000656 |

*Table 4. Mean signed reward contributions over all 600 original seeds and all 320 steps, in raw reward units. Positive favors A2; a negative penalty contribution means A2 incurred more of that penalty. The four terms sum to the total before rounding, with maximum numerical residual 2.79e-15. The reward floor contributes zero under the original weights. Values are accounting under the fixed synthetic reward, not percentages or physical benefits.*

Against S, hazard credit improves on 500/600 seeds, but pack penalties worsen on 594/600. The positive credit +0.003572 is reduced to +0.001635 after penalties. Against N the net gain is only +0.000198; C leaves +0.000656. A2 gains one designed reward component while accepting other costs.

First-action and full-path signs disagree on 295/600 S, 308/600 N and 301/600 C comparisons. Against N, 272 of 528 initially losing traces finish ahead, versus 36 of 72 initially winning traces (51.5% versus 50.0%). These counts do not establish strategic sacrifice for later gain. After divergence the states can differ. The full 3x3 matrices, all 1,800 first-difference records and gain/loss-conditioned component means remain public in v1.9.

### 2.3 Reward-Weight Sensitivity and Final A2 Judgment

We rescore the same fixed trajectories with:

$$r_{a,b,c}=\max(0.05,\;0.50+0.42a h-bD-0.14cP).$$

Only the three outer weights change; internal definitions, constant, floor and policies stay fixed. Reward is not an input to the policies or state transitions, so these trajectories remain valid for the changed objectives. This is retrospective objective sensitivity, not policy retraining or a physical uncertainty model.

Before computing these sensitivities, we fixed one-at-a-time factors {0.5,0.75,1,1.25,1.5,2}, holding the other two at 1, and all 27 joint combinations of {0.75,1,1.25}. Deduplication gives 36 configurations. The 0.05 floor is reapplied at each step; simply reweighting Table 4 would miss clipping. All 86,400 policy-seed-configuration means exactly match direct reward-modified simulation; the 2,400 original means remain exact. Comparisons use raw rewards, not the original-reference U under a changed objective.

Figure 2 shows the one-at-a-time results. Halving hazard-credit weight makes A2 last among the four policies: margins against S/N/C are -0.000140/-0.000163/-0.000466. Raising the action penalty to 1.5 times its weight puts N ahead (A2 margin -0.000024); doubling the pack penalty puts C ahead (-0.000561). Each individual +/-25% weight change keeps A2's mean first, but simultaneous changes need not. In the joint cube, A2 is first in 22 configurations, second in three and third in two. Its mean exceeds S in 27/27, N in 23/27 and C in 24/27; there are no mean ties. These counts describe chosen grid points, not robustness probabilities or a continuous guarantee.

![Reward-weight sensitivity of fixed policies](images/reward_sensitivity.png)

*Figure 2. Mean A2-minus-alternative raw reward under all six one-at-a-time factors, using the same 600 seeds per point. Values are multiplied by 1,000 for legibility, not percentages. Dotted vertical lines mark original weights; horizontal zero marks equal mean. Lines connect evaluated grid points without certifying intervening behavior. The complete 36 configurations, clipping counts and per-seed results are public.*

**Final judgment:** retain A2 as a conditional follow-up candidate in this synthetic setting. Relative to S it buys higher original mean with six extra nodes and losses; relative to N it saves two nodes with a small mean edge; relative to C it changes weighting at equal size. The latter two preferences can reverse even within the joint +/-25% grid. A2 is therefore not a default replacement or a reward-independent winner. No acceptable-loss threshold or deployment-cost benefit has been established. A1 complements this result: its preference changes with the comparator set, while A2's changes with the objective.

### 2.4 A1: Broader Comparison Changes the Judgment

A1 ranks synthetic queues by adding the smaller of drift and burst to queue, then subtracting half idle. Both signals must be high for a large added priority. This exact minimum coupling is absent from H. 

The same-block comparison initially favors A1: nine nodes and test U=1.003905 versus 13 nodes and U=1.000870 for N_ROLE. Expanding to all original winners reveals the seven-node neutral alternative in Table 1. Section 3 shows why the larger comparison set weakens the adoption judgment even though the minimum rule is easy to explain.

The saved sequence records a coefficient change: round 2 slot 6 contains `queue+min(drift,burst)-0.25*idle`; round 3 changes -0.25 to -0.5 after that output and its feedback are supplied. The sequence establishes the visible revision, not its internal rationale.

### 2.5 A5: Above Reference Is an Incomplete Adoption Argument

A5 changes a supplied queue template's coefficients and omits burst. Its test U=1.002104 exceeds the simple reference, but the matched neutral expression in Table 1 reaches 1.003917 with seven nodes/depth 2 versus nine/depth 3. This comparison motivates deprioritization rather than labeling A5 a failed generation. Paired outcomes are retained in Section 3.2.

A5 was fixed by the low-selection rule, not chosen for a poor test outcome. The preceding round has `queue*(0.4+drift)-0.3*idle`; A5 revises the coefficients after feedback.

### 2.6 A3 and A4: Supplied Structures Remain Visible

A3 adjusts idle with an upper-capped frequency term and positive jitter, both supplied in H. For freq below 0.5, subtracting the negative min term adds a bonus; at freq at least 0.75 the contribution is fixed at -0.0875. Earlier rounds use cap weights 1 and 0.6; A3 uses 0.35. Test U=1.000466 and depth 4, above the soft target of 3, make it a low-priority diagnostic rather than evidence of cloud-cost savings.

A4 combines the supplied temperature, soc*imped and threshold terms, doubling the threshold weight. The preceding round contains both the doubled threshold without the product and the product with weight one. Test U=1.009928 exceeds the matched X_ROLE winner's 1.008923, with 13 nodes/depth 4 versus 11/depth 3. It is an X_FLAT assembly/control example, not a newly established domain connection.

## 3. Comparison with All Original Winners

### 3.1 Position among Original Winners and All Submissions

We rank fixed cases among 30 original winners per task, separately on selection and test, without pooling task utilities. Duplicate outcomes remain: Network and Thermal have 28 and 26 distinct strings. Rank is one plus the number of strictly higher utilities (tolerance 1e-12); this is descriptive, not a generation-effect estimate.

An alternative size-reward dominates a policy if it uses no more nodes and has no lower utility, with one strict difference. We assess each split separately. This rule has no practical-effect threshold; tiny differences can change the status.

A2 ranks 1/30 on both splits and is not size-reward dominated on either; A1 ranks 5/30 and is dominated on both. Among all submitted occurrences, A2 ranks 1/360 on selection and 1/306 available tests; A1 ranks 7/360 and 7/327. The 54 Thermal and 33 Network submissions without tests are not failures. Available-test ranks are not ranks over all 360 submissions.

A2 is not dominated: its test U=1.011170 exceeds the simpler cubic alternative's 1.009897, with 13 rather than seven nodes. A1's two dominators are instances of the same seven-node expression, from Network N_ROLE block 5 and N_FLAT block 6. Its test U=1.003917 is only about 0.000012 above A1; the selection advantage is approximately 4.38e-8. Expression size, rather than a demonstrated practically important score increment, drives the preference. We describe the first instance by session ID; both have identical formulas and stored traces.

Test coverage follows the original evaluation procedure, not random sampling. Public files retain all 90 winner ranks/dominators. The 360-submission view supplies ranks only; per-seed comparisons concern original winners.

### 3.2 Average Gains and Observed Downside

For each case, we subtract each same-task alternative's raw reward on the identical saved seed. This gives 30 comparisons including self, plus the reference, or 62 comparisons across A1/A2. The within-block contrast remains identifiable, while comparisons to other blocks describe fixed policies rather than paired generation interventions. Joins require 600 matching seeds and equal references.

A win has a difference above 1e-12; a tie is within that tolerance. Table 5 shows the mean difference, the mean of the 30 lowest differences (observed bottom 5%) and the largest observed loss. These are task-specific raw-reward quantities, not percentages. They describe this set of traces, not a bound on future risk or 600 independent model generations.

| Case | Comparator | Wins/ties/losses | Mean difference | Lowest-30 mean | Largest loss |
| --- | --- | --- | ---: | ---: | ---: |
| A2 | Reference | 599/0/1 | +0.014354 | +0.005077 | 0.000154 |
| A2 | S: X_FLAT B5, 7 nodes | 390/0/210 | +0.001635 | -0.006591 | 0.010608 |
| A2 | N: N_FLAT B6, 15 nodes | 308/0/292 | +0.000198 | -0.006281 | 0.008701 |
| A2 | C: X_FLAT B2, 13 nodes | 342/0/258 | +0.000656 | -0.006834 | 0.012074 |
| A1 | Reference | 514/0/86 | +0.003800 | -0.003681 | 0.007333 |
| A1 | N_ROLE B4: same block | 402/0/198 | +0.002953 | -0.004802 | 0.009958 |
| A1 | N_ROLE B5: simpler | 9/569/22 | -0.000012 | -0.000306 | 0.001276 |

*Table 5. Gain and downside on saved common-seed traces. B denotes block. A negative lowest-30 mean indicates losses in that tail; largest loss is reported as a positive magnitude. The A1 seven-node comparator is identified by the selection-data dominance relation, not by searching test outcomes. The full supplement retains all 62 comparisons, medians, fifth percentiles and conditional gains/losses. S/N/C do not add comparisons to that set; their new step records come from local replay.*

The earlier comparisons for the other fixed cases are retained: A3 versus reference has 359 wins, no ties and 241 losses, with mean raw margin +0.000412; A4 has 599/0/1 and +0.012758. A5 versus its same-block N_ROLE alternative has 270/2/328 and -0.001764. Their complete matched-condition records remain in the v1.4 analysis.

Gain/loss contributions explain the averages. For A2 versus the simpler cubic rule, +0.002580 gain contribution minus 0.000945 loss contribution gives +0.001635. Against the same-block N_ROLE winner, A1's +0.003617 minus 0.000664 leaves +0.002953; against the smaller cross-block rule, +0.00000355 minus 0.00001530 gives -0.00001176. Contributions divide all positive and absolute negative differences by 600, including differences within the tie tolerance; the supplement also gives conditional averages over only the corresponding signed cases.

Equal rewards do not establish identical actions, and whole-formula comparisons do not isolate min or cubic effects. The reported downside informs the conditional judgments in Section 2; no acceptable-loss or minimum-useful-gain threshold was specified.

### 3.3 Interesting Structures Are Not Exclusive to Cross-Domain Roles

We also audit two explicitly defined motifs throughout the complete saved catalogue. After removing whitespace, we search for the exact substrings `min(drift,burst)` in Network and `stress*stress*stress` in Thermal. This is a narrow, reproducible string census, not semantic clustering or an exhaustive search for algebraically equivalent rules. Counts are retrospective and were chosen because of A1/A2.

The minimum motif appears in four X_ROLE submissions from one session, one N_ROLE submission from one session and one X_FLAT submission from one session. It is absent under this literal rule in N_FLAT and DOMAIN_V2. The cubic motif appears in seven X_FLAT submissions from five sessions, three N_FLAT submissions from one session and two X_ROLE submissions from one session; it is absent under the rule in N_ROLE and DOMAIN_V2. Each task/condition has six sessions and 72 submissions. Repeated submissions from a session are not independent discoveries.

These records sharpen the main distinction: a structure can be absent from H, interpretable and promising in a selected comparison without being specific to the cross-domain package. The minimum and cubic motifs are not evidence that biological, HCI or design knowledge caused the corresponding terms. Their neutral-condition occurrence is part of the finding, not an example to omit.

### 3.4 Complete Collection and Retrospective Selection

All 1,080 submissions pass the recorded validity gate, with 822 distinct within-domain exact strings (spacing/algebraic variants remain separate), 916 component representative instances and 90 original winners. The catalogue retains every occurrence with complete prompt/response provenance, syntax, selection status, component and scores. Tests exist for 944 submissions; 136 remain untested, not failed.

The offline catalogue supports expression search and provenance/score filters. Syntactic tags locate forms, not semantic novelty or cognitive processes; case cards retain the exact H beside each output.

We fix three core cases: the original X_ROLE session winner with highest selection utility in each domain. Ties use nodes, depth, session ID and slot ID in ascending order. One X_FLAT complement is selected from original winners with a tag combination absent from the core cases, using Network-Thermal-Cloud domain order and the same ranking within the first eligible domain. One low-selection X_ROLE example uses that domain order, minimum selection utility, and the same tie rules after excluding already used domain/expression pairs. A missing eligible complement would be omitted.

The selection function receives only selection/provenance/syntax fields. It writes case IDs and a rule hash before attaching test values, without replacing cases after attachment. Nevertheless, the rule was devised after pilot results had been inspected: these are **post-hoc descriptive cases, not five prevalidated successes or the global best five outputs**. Matched comparison rows are the original winners of all five conditions in the same domain/block. Full inclusion/exclusion logs are public.

## 4. Inputs, Generation, and Evaluation

### 4.1 Source Perspectives and Target Tasks

Biological/HCI and design language supplies guidance; Network, Thermal and Cloud receive generated rules. Network ranks four synthetic queues, Thermal ranks four synthetic modules for derating, and Cloud ranks six synthetic slots for reclamation. In each task, the expression assigns scores to options and the highest score determines the selected option. Features are normalized to [0,1] by clipping negative raw values at zero and applying x/(1+x). Ties retain the first option.

Expressions use four task variables, constants, arithmetic, min, max, and abs. All conditions share a hard gate of 25 AST nodes and implemented depth 5, with soft targets of 14 nodes and depth 3. Recorded depth flattens additive/subtractive and multiplication chains; it is not ordinary binary-tree height. Each environment trace has 320 steps, with handcrafted transitions and rewards; task names do not imply validated physical or production systems.

The four factorial conditions share the hints in Table 7. The cross-domain instruction asks the model to interpret them through biological immune-adaptation and HCI reframing analogies, using minimalist industrial-design inspiration for concise expressions. ROLE assigns exploration and simplicity distinct functions within the same response; FLAT presents both together. These are prompt instructions, not observed internal stages. DOMAIN_V2 omits H and changes the guidance procedure, so it is descriptive rather than a single-module ablation.

| Condition | Framing | Organization | H |
| --- | --- | --- | --- |
| N_FLAT | Neutral | Combined | Yes |
| N_ROLE | Neutral | Roles | Yes |
| X_FLAT | Cross-domain | Combined | Yes |
| X_ROLE | Cross-domain | Roles | Yes |
| DOMAIN_V2 | Domain | Base | No |

*Table 6. Conditions. Every factorial arm includes exploration and simplicity guidance. Roles are textual within one response.*

| Task | Shared mathematical hints H |
| --- | --- |
| Network | `queue*(0.45+drift)`; `max(burst-idle,0)`; negative idle term |
| Thermal | `soc*imped`; `max(stress-0.5,0)`; temperature term |
| Cloud | `cost*freq`; `min(freq-0.5,0.25)`; positive jitter with idle |

*Table 7. H is supplied to all four factorial conditions within a task. The Cloud min term is an upper cap, not a lower clamp. Exact complete prompts and their verbatim differences are public.*

### 4.2 Recorded Generation and Evaluation

The pilot ran on 24 October 2026 (KST), requesting gpt-6.1-sol with low reasoning effort through Codex CLI 0.162.1. Three domains, six paired blocks per domain, and five conditions give 90 separately initialized sessions. Randomized condition order within domain/block and four rounds of three expressions yield 360 responses and 1,080 slots. Each session receives only its own prior answers and feedback. The required response is an expression array without explanatory commentary, so the record does not reveal the model's internal rationale.

The experimental message roles were serialized into one CLI input rather than sent as native API roles. Actual prompt length, semantics, and token use were not exactly matched; the requested 2,048-token output cap was not enforced. Thus the contrasts concern the recorded instruction packages, not perfectly resource-matched interventions or verified server snapshots.

Feedback, selection and test use disjoint base seeds: 48 (1000001-1000048), 96 (1100001-1100096), and 600 (1200001-1200600), with fixed Thermal/Cloud offsets. Selection starts after generation, and selected policies and representatives are frozen before test access. Independent generation comparisons use sessions; each session's 12 submissions are dependent.

The reference expressions are queue+0.45*drift+0.15*burst-0.15*idle for Network, temp+0.4*soc+0.35*imped+0.25*stress for Thermal, and idle for Cloud. Historical labels Adaptive-PI, PID-lite, and Fixed-TTL denote simplified synthetic formulas, not full implementations of those methods. Utility U is the policy's mean trace reward divided by the reference's mean reward on the same domain/split; the reference has U=1. This ratio is not an average of per-trace ratios. References are comparison points, not optima or tuned published competitors.

Behavioral groups use the saved graph on a fixed four-value-per-coordinate grid and 500 diagnostic option panels. An edge requires Spearman score correlation above 0.98 and top-action agreement of at least 95 percent. Connected components may contain transitive chains; they are finite-probe groups within a session, not globally unique ideas. Each representative and the overall session winner are chosen by selection mean reward, with expression-hash and slot tie breaks, then evaluated on test. The original primary outcome counts representatives with U at least 0.99. This near-reference criterion permits below-reference policies and is not a practical improvement threshold. Strict exceedance uses U greater than 1+1e-9. The analysis was locally frozen before test access, not publicly preregistered.

## 5. Aggregate Evidence and Boundaries

Selected examples do not replace the original experiment. Equal-domain averaging of six within-block contrasts gives -0.1111 near-reference components per session for X_ROLE minus N_ROLE. The Network, Thermal and Cloud means are -0.6667, +0.1667 and +0.1667, with paired SDs 2.9439, 2.2286 and 4.4907. Figure 3 retains all 18 differences. Six paired blocks per domain are the generation comparisons; test traces do not enlarge that sample.

![Original paired near-reference differences](images/paired_differences.png)

*Figure 3. Original X_ROLE minus N_ROLE near-reference counts by block and domain. Selected artifact examples must be read alongside this mixed aggregate result.*

| Outcome | X_ROLE−N_ROLE | X_ROLE−X_FLAT | Interaction |
| --- | ---: | ---: | ---: |
| Primary count | −0.1111 | −0.5556 | −1.2222 |
| Strict-exceedance count | +0.3333 | +0.6667 | +0.3889 |
| All-pairs count | −0.0556 | −0.4444 | −1.1111 |
| Selected-policy utility | +0.000998 | −0.000144 | +0.000062 |

*Table 8. Preserved aggregate comparisons. Interaction is (X_ROLE−X_FLAT)−(N_ROLE−N_FLAT). Counts and utility answer different questions. The utility contrast is not a relative percentage gain.*

The v1.2 retrospective profiles also remain relevant. Relative to N_ROLE, X_ROLE has 0.5370 more mean nodes and 0.3889 fewer pre-threshold components per session; relative to X_FLAT, the differences are +0.8148 and -0.4444. The node difference is mainly Thermal (+1.5556), with Network -0.1667 and Cloud +0.2222. All 12 submissions contribute to session means, including repeats. These profiles do not support an aggregate simplicity-diversity advantage and do not identify a compression process. Full tables and figures remain in the supplement.

Cloud further separates usable-looking artifacts from broad performance claims. Of 304 representative instances, 178 are below 0.99, 118 lie from 0.99 through 1, and eight strictly exceed 1+1e-9, between 1.000012 and 1.000541. Thus 126 meet the near-reference threshold, but only eight exceed the reference; 25 of 30 originally selected Cloud policies are below it. No representatives cross either threshold between saved selection and test splits. This does not rule out selection bias or explain the source of the generated rules.

The common limits apply to all case interpretations. The study uses one requested model/effort, one wording per condition, six paired blocks per task, shared H overlapping reward features, handcrafted transitions/rewards and simple references. Actual token budgets were not matched. Every factorial arm already contains both guidance functions; there are no exploration-only, design-only or bare-length controls. The case rule is retrospective and not representative sampling. Test ranks and observed downside are descriptive; no confidence intervals, equivalence decisions, user ratings or deployment evidence are added.

The catalogue and replay support inspection of outputs and follow-up priorities. They do not reveal which source-domain knowledge was used or show that cross-domain wording caused the structures. Neutral-condition occurrences and the original mixed aggregate result constrain that claim. The supplied soc*imped hint also overlaps the handcrafted reward, which uses the raw-variable product, temperature and a stress threshold. Replay explains choices under that design; it does not remove this overlap. Separating domain-guidance effects and validating practical benefit require evidence beyond these comparisons.

## 6. Conclusion and Reproduction

This exploratory study links cross-domain prompt guidance to inspectable outputs and conditional judgments. A2 has the highest original observed Thermal mean, but nearby alternatives and reweighted rewards limit its appeal. Its hazard-credit gains coexist with larger penalties; its lead over N/C can reverse within the joint +/-25% grid. We retain it for follow-up under explicitly chosen objectives, without recommending deployment. A1 shows the parallel importance of broadening the comparator set.

The documented supplied-to-generated changes support conditional assessment, while the five cases, neutral motifs and mixed aggregate constrain interpretation. Biological/HCI transfer, algorithmic novelty and practical utility remain unestablished.

The v1.10.0 paper, source, sensitivity code/results and Korean guide are public: [https://github.com/7065616b/symbolic-policy-framing-pilot](https://github.com/7065616b/symbolic-policy-framing-pilot). Earlier prompts, catalogues and replay evidence remain unchanged. No model calls, new policies or test seeds are added; rescoring supplies no independent observations. Model regeneration is not guaranteed without server snapshots and sampling seeds.

## References

- **[1]** B. Romera-Paredes, M. Barekatain, A. Novikov, M. Balog, M. P. Kumar, E. Dupont, F. J. R. Ruiz, J. S. Ellenberg, P. Wang, O. Fawzi, P. Kohli, and A. Fawzi, "Mathematical Discoveries from Program Search with Large Language Models," *Nature*, vol. 625, pp. 468–475, 2024.
- **[2]** F. Liu, X. Tong, M. Yuan, X. Lin, F. Luo, Z. Wang, Z. Lu, and Q. Zhang, "Evolution of Heuristics: Towards Efficient Automatic Algorithm Design Using Large Language Model," in *Proc. Int. Conf. Machine Learning (ICML)*, 2024.
- **[3]** H. Ye, J. Wang, Z. Cao, F. Berto, C. Hua, H. Kim, J. Park, and G. Song, "ReEvo: Large Language Models as Hyper-Heuristics with Reflective Evolution," in *Advances in Neural Information Processing Systems*, vol. 37, 2024. [Proceedings](https://papers.nips.cc/paper_files/paper/2024/hash/4ced59d480e07d290b6f29fc8798f195-Abstract-Conference.html).
- **[4]** P. V. T. Dat, L. Doan, and H. T. T. Binh, "HSEvo: Elevating Automatic Heuristic Design with Diversity-Driven Harmony Search and Genetic Algorithm Using LLMs," in *Proc. AAAI Conf. Artificial Intelligence*, vol. 39, no. 25, pp. 26931–26938, 2025. [doi:10.1609/aaai.v39i25.34898](https://doi.org/10.1609/aaai.v39i25.34898).
- **[5]** E. Meyerson, M. J. Nelson, H. Bradley, A. Gaier, A. Moradi, A. K. Hoover, and J. Lehman, "Language Model Crossover: Variation through Few-Shot Prompting," *ACM Transactions on Evolutionary Learning and Optimization*, vol. 4, no. 4, Art. 27, 2024. [doi:10.1145/3694791](https://doi.org/10.1145/3694791).
- **[6]** M. H. Nguyen, S. Tschiatschek, and A. Singla, "Enhancing Diversity of LLM-Generated Educational Tasks," *arXiv:2512.23601v2*, 2026; author-reported EDM 2026 poster paper. [Consulted version](https://arxiv.org/abs/2512.23601v2).
- **[7]** A. Shen, S. Druckmann, and J. Zou, "Unlocking LLM Creativity in Science through Analogical Reasoning," *arXiv preprint arXiv:2605.11258v1*, 2026. [Consulted version](https://arxiv.org/abs/2605.11258v1).
- **[8]** P. H. Luz de Araujo, P. Röttger, D. Hovy, and B. Roth, "Principled Personas: Defining and Measuring the Intended Effects of Persona Prompting on Task Performance," in *Proc. Conf. Empirical Methods in Natural Language Processing*, pp. 26857–26886, 2025. [doi:10.18653/v1/2025.emnlp-main.1364](https://doi.org/10.18653/v1/2025.emnlp-main.1364).
- **[9]** J.-B. Mouret and J. Clune, "Illuminating search spaces by mapping elites," *arXiv preprint arXiv:1504.04909*, 2015. [Original preprint](https://arxiv.org/abs/1504.04909).
- **[10]** M. Yasunaga, X. Chen, Y. Li, P. Pasupat, J. Leskovec, P. Liang, E. H. Chi, and D. Zhou, "Large Language Models as Analogical Reasoners," in *Proc. Int. Conf. Learning Representations (ICLR)*, 2024.

## Summary of This Paper

### Problem Setup

This exploratory study examines symbolic policies generated under prompt-level composition of biological/HCI exploration and minimalist-design guidance. The prompt names the source perspectives and also supplies task facts, mathematical hints, grammar and feedback. The question is which saved outputs merit further examination, not whether a causal cross-domain benefit has been established.

### Novelty

The contribution is a traceable assessment of supplied elements, generated changes and conditional candidate value. A2's preference depends on reward weights; A1's depends on comparator scope. These fixed retrospective cases do not establish a new algorithm, mathematical invention, module synergy or causal domain transfer.

### Algorithms

The original 90 sessions yield 1,080 submissions with separate feedback, selection and test data. All five case IDs and original winners remain fixed; the presentation order does not reselect policies on test results. A1/A2 comparisons cover all 30 original winners in their own task and 62 common-seed comparisons. Secondary ranks disclose missing test values among all 360 task submissions. Four existing policies are replayed on the original 600 seeds, with exact agreement for all 2,400 saved rewards. All 1,800 comparator-seed pairs receive reward-component and first-divergence diagnostics; six sign-conditioned pairs illustrate complete trajectories. Neither increases the independent sample. Thirty-six fixed weight configurations rescore the same paths with the floor applied at each step; all 86,400 scores match direct reward-modified simulation.

### Experiments

A2 ranks first among 30 Thermal winners on both saved splits. Against the seven-node cubic alternative, its 13-node expression has mean raw margin +0.001635, 390 wins and 210 losses, with largest observed loss 0.010608. Against the strongest selection-ranked neutral winner, A2 has 308 wins and 292 losses, with mean margin +0.000198 and 13 versus 15 nodes. Against N, 272/600 traces finish positive after an initially negative margin, while 36 do the reverse; the mean hazard-credit gain is largely offset by penalties. A1 ranks fifth among 30 Network winners; two instances of a smaller neutral rule have slightly higher means, and the paired results against that rule are 9 wins, 569 ties and 22 losses. A2 ranks first of 360 submissions on selection and first of 306 tested occurrences; A1 ranks seventh of 360 and seventh of 327. The original X_ROLE minus N_ROLE primary contrast remains -0.1111 near-reference components per session, with strict exceedance +0.3333. Neutral-condition motifs, shared hints, one requested model, six blocks per task, synthetic environments and retrospective emphasis limit interpretation. A2 ranks first among four fixed policies in 22/27 joint +/-25% weight configurations, but loses to N in four and C in three; halving hazard-credit weight makes it last. Grid counts are not probabilities. A2 remains a conditional follow-up candidate; causal cross-domain effects and practical utility remain unresolved.
