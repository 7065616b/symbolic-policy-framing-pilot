# Submission materials v1.10.3

Cross-Domain Skill Composition: An Exploratory Study of Generated Policies

This version was uploaded to JKAIA2026 submission 54, General (Full Paper). The matching Korean registration abstract was also updated. Submission does not imply acceptance.

The abstract and introduction first explain the research question: ask an AI to combine perspectives from different fields, generate small executable selection rules, and examine which outputs merit further study. Biology/HCI and minimalist design supply guidance; Network, Thermal and Cloud are the synthetic target tasks. Technical labels are introduced in the methods section. Numerical results and scientific limitations are preserved.

The official class, font defaults and margins are unchanged. Compile main.tex from this folder with Tectonic and an available TeX bundle. The PDF has eight body pages, one references page and one required summary page, with eight tables and three figures. No new model calls or experiments were run.
