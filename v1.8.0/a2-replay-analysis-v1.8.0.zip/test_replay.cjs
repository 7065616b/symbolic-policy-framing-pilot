'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {loadFrozen,makeObserved,runAudit,firstDivergence}=require('./replay.cjs');
const {DOMAIN_SCI}=require('./vendor/simulators.js');
let audit;
test.before(()=>{audit=runAudit(__dirname);});
test('all frozen policies, seeds and reference means match both original and observed replay',()=>{
  assert.equal(audit.verification.policySeedPairs,2400);
  assert.equal(audit.verification.referenceSeeds,600);
  assert.equal(audit.verification.maxSavedAbsoluteError,0);
  assert.equal(audit.verification.maxInstrumentationAbsoluteError,0);
});
test('observer preserves strict tie behavior and original reward',()=>{
  const records=[];const value=makeObserved(r=>records.push(r))(()=>0,1200001,320);
  assert.equal(value,DOMAIN_SCI.simulateTrace(()=>0,1200001,320));
  assert(records.every(r=>r.action===0));assert.equal(records.length,320);
});
test('step accounting, normalized pre-action inputs and all four scores are recorded',()=>{
  for(const example of audit.examples)for(const trajectory of [example.a2,example.alternative]){
    assert.equal(trajectory.length,320);
    for(const r of trajectory){
      assert.equal(r.states.length,4);assert.equal(r.scores.length,4);
      assert.equal(r.stepReward,Math.max(0.05,0.50+0.42*r.hazardMitigated-r.unnecessaryDerateLoss-0.14*r.packHazard));
      for(let i=0;i<4;i++)for(const k of ['temp','soc','imped','stress'])assert.equal(r.states[i][k],r.rawStates[i][k+'Raw']/(1+r.rawStates[i][k+'Raw']));
    }
  }
});
test('all six illustrations follow the stated seed rule and have identical states at first divergence',()=>{
  assert.equal(audit.examples.length,6);
  for(const e of audit.examples){
    const row=audit.margins.find(r=>r.comparator===e.comparator && (e.sign==='gain'?r.margin>1e-12:r.margin< -1e-12));
    assert.equal(e.seed,row.seed);
    const d=firstDivergence(e.a2,e.alternative);
    assert.equal(d.step,e.firstDivergence.step);
    assert.deepEqual(d.a2.rawStates,d.alternative.rawStates);
    assert.notEqual(d.a2.action,d.alternative.action);
  }
});
test('full-seed comparisons reproduce previously published counts and means',()=>{
  const expected={S:[390,210,0.0016351186340663407],N:[308,292,0.00019832692813836705],C:[342,258,0.0006561350724349009]};
  for(const c of audit.comparisons){const e=expected[c.key];assert.equal(c.wins,e[0]);assert.equal(c.losses,e[1]);assert.equal(c.ties,0);assert(Math.abs(c.meanMargin-e[2])<1e-14);}
});
test('whole-trajectory reward decomposition reconciles all six trace margins',()=>{
  for(const e of audit.examples){
    assert(e.rewardDecomposition,'reward decomposition must be exported');
    const p=e.rewardDecomposition;
    assert(Math.abs(p.hazardCredit+p.unnecessaryPenalty+p.packPenalty+p.floorAdjustment-e.traceMeanMargin)<1e-12);
  }
  const e=audit.examples.find(e=>e.comparator==='S' && e.sign==='gain');
  assert(Math.abs(e.rewardDecomposition.hazardCredit-0.00588179884879765)<1e-14);
  assert.equal(e.rewardDecomposition.floorAdjustment,0);
});
test('corrupted stored reward, duplicate seed and changed pinned source fail closed',()=>{
  const loaded=loadFrozen(__dirname);
  const bad=structuredClone(loaded.frozen);bad.policies[0].perSeed[0].raw+=0.01;
  assert.throws(()=>runAudit(__dirname,bad),/saved reward/);
  const dup=structuredClone(loaded.frozen);dup.baseSeeds[1]=dup.baseSeeds[0];
  assert.throws(()=>runAudit(__dirname,dup),/seeds/);
  const pinned=structuredClone(loaded.manifest);pinned.files['vendor/simulators.js']='0'.repeat(64);
  assert.throws(()=>loadFrozen(__dirname,pinned),/hash/);
});
