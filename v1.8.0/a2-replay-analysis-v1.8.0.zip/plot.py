"""Plot saved replay records only; Python + matplotlib, no model calls."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent
examples=json.loads((root/'results/examples.json').read_text())
selected=[next(e for e in examples if e['comparator']==c and e['sign']==s) for c,s in [('S','gain'),('S','loss'),('N','gain')]]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':11})
fig,axes=plt.subplots(1,3,figsize=(11.8,3.1),layout='constrained')
for ax,e in zip(axes,selected):
 x=[r['step'] for r in e['a2']];y=[a['cumulativeReward']-b['cumulativeReward'] for a,b in zip(e['a2'],e['alternative'])];d=e['firstDivergence'];color='#235c82' if e['sign']=='gain' else '#a4482b'
 ax.plot(x,y,color=color,lw=1.5);ax.axhline(0,color='#777',lw=.7);ax.axvline(d['step'],color='#999',lw=.8,ls='--')
 ax.scatter([d['step']],[y[d['step']-1]],s=20,color=color,zorder=3)
 ax.set_title(f"A2 - {e['comparator']}: {e['sign']} trace\nseed {e['seed']}");ax.set_xlabel('Step');ax.set_xlim(1,320);ax.grid(axis='y',alpha=.2)
 for side in ['top','right']:ax.spines[side].set_visible(False)
axes[0].set_ylabel('Cumulative raw reward difference')
for ext in ['pdf','png']:fig.savefig(root/f'a2_replay.{ext}',dpi=180,**({'metadata':{'CreationDate':None,'ModDate':None}} if ext=='pdf' else {}))
plt.close(fig)
