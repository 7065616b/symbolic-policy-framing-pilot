# A2 local replay, v1.8.0

This is a retrospective diagnostic of four existing original Thermal winners and their 600 existing test seeds. It makes no model calls, generates no new policy or seed, and adds no independent validation sample. The original source data and all earlier public versions remain unchanged.

## Reproduce

Requires Node.js (verified with v24.19.0), with built-in modules only. Run from this directory:

```text
node --test test_replay.cjs
node replay.cjs --out reproduced
```

The five JSON/CSV outputs in `reproduced` match their counterparts in `results` byte for byte. `results/figure_data.json` additionally contains the plotted cumulative differences. The figure can be regenerated from the trace data with `python plot.py` (Python and matplotlib required).

The test suite covers exact agreement for 2,400 policy-seed means and 600 reference seeds, unchanged instrumentation, strict action ties, normalized states, reward-component accounting, first-divergence equality, example selection, prior comparison counts, and corrupted-data rejection. `manifest.json` pins the five input/vendor files and records hashes of their original public sources. The observer adds logging to the original function's source at checked anchors; it does not rewrite its dynamics. The original uninstrumented function is called independently for every policy-seed pair.

## Policies and examples

- A2: `pilot-Thermal-05-X_ROLE-slot10`, 13 nodes.
- S: `pilot-Thermal-05-X_FLAT` original winner, 7 nodes; previously fixed matched comparator.
- N: `pilot-Thermal-06-N_FLAT` original winner, 15 nodes; highest selection utility among the 12 neutral original Thermal winners.
- C: `pilot-Thermal-02-X_FLAT` original winner, 13 nodes; highest selection utility among other original Thermal winners with 13 nodes and the literal cubic motif. It is an existing close formula, not a fitted coefficient ablation.

All comparisons were already available in the v1.5.0 saved-data audit. The new contribution here is the step record. For each comparator, take the smallest saved base seed with positive mean margin and the smallest with negative mean margin (tolerance 1e-12). Show its first differing action. The rule is retrospective and conditioned on outcome sign; the six pairs are neither randomly sampled nor representative. It does not maximize the displayed margin. We retain the case where the first immediate margin and the final trace margin have opposite signs.

The base seeds are 1200001 through 1200600. The original Thermal function adds 10000 once internally. Each trace has 320 steps and four modules. Stored JSON action indices are zero-based; paper/guide module and step numbers are one-based. Steps in the JSON are already one-based.

At the first differing action, both policies have identical pre-action states. Later states can differ because actions change the environment. Same seed does not mean identical later states. `rewardDecomposition` accounts for observed path rewards; it does not isolate the causal effect of one expression term. Raw state and normalized policy inputs are both retained. The supplied product hint overlaps a raw-variable product in the reward function.

## Files

- `inputs/frozen_policies.json`: exact four expressions, identities, sizes, selection metrics and saved seed rewards.
- `inputs/original_winners.csv`, `inputs/all_alternative_comparisons.csv`: unchanged earlier comparison data.
- `vendor/`: unchanged public simulator and AST evaluator; hashes pinned.
- `results/comparison_summary.json`: close-alternative comparisons and fixed-policy metadata.
- `results/all_seed_margins.csv`: 1,800 comparisons (three alternatives times 600 seeds).
- `results/examples.json`: six complete trajectory pairs, all four module inputs and scores at every step, actions and reward components.
- `results/example_summary.json`: first-divergence states, trace margins and reward decomposition.
- `results/replay_verification.json`: exact-parity verification.
- `report_ko.md`: readable analysis in Korean.

The simulator is handcrafted and synthetic. Physical-sounding comments in the archived vendor file are preserved for provenance, not endorsed as validated electrochemistry. Replay cannot establish cross-domain knowledge transfer, practical safety, deployment utility, or a generation-treatment effect. The original aggregate contrast and all earlier limitations remain.
