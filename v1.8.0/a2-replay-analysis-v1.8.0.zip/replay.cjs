'use strict';
// Local, deterministic observer only. No network, model adapter or policy search.
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const {DOMAIN_SCI,mulberry32,norm}=require('./vendor/simulators.js');
const {analyzeAndCompileCandidate}=require('./vendor/ast_evaluator.js');
const TOL=1e-12;
const mean=xs=>xs.reduce((a,b)=>a+b,0)/xs.length;
const hash=buffer=>crypto.createHash('sha256').update(buffer).digest('hex');

function loadFrozen(root,manifestOverride){
  const manifest=manifestOverride??JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));
  for(const [file,expected] of Object.entries(manifest.files))assert.equal(hash(fs.readFileSync(path.join(root,file))),expected,'pinned hash: '+file);
  const frozen=JSON.parse(fs.readFileSync(path.join(root,'inputs/frozen_policies.json'),'utf8'));
  return {manifest,frozen};
}
function makeObserved(observe){
  let src=DOMAIN_SCI.simulateTrace.toString();
  const insert=(anchor,replacement)=>{
    assert.equal(src.split(anchor).length,2,'instrumentation anchor must occur once: '+anchor);
    src=src.replace(anchor,replacement);
  };
  insert('simulateTrace(', 'function simulateTrace(');
  insert('let bestIdx = 0;', 'const observedStates = [], observedScores = [];\n      let bestIdx = 0;');
  insert('const sc = policyFn(state);','const sc = policyFn(state);\n        observedStates.push({...state}); observedScores.push(sc);');
  insert('const target = cells[bestIdx];','const observedRaw = cells.map(cell => ({...cell}));\n      const target = cells[bestIdx];');
  insert('totalUtility += stepReward;',`totalUtility += stepReward;
      observe({step:t+1,rawStates:observedRaw,states:observedStates,scores:observedScores,
        action:bestIdx,hazardMitigated,unnecessaryDerateLoss,packHazard,stepReward,cumulativeReward:totalUtility});`);
  return new Function('mulberry32','norm','observe','return ('+src+');')(mulberry32,norm,observe);
}
function firstDivergence(a,b){
  const i=a.findIndex((r,i)=>r.action!==b[i].action);
  assert(i>=0,'illustration must contain an action divergence');
  assert.deepEqual(a[i].rawStates,b[i].rawStates,'first divergence must have equal pre-action states');
  return {step:a[i].step,a2:a[i],alternative:b[i],immediateMargin:a[i].stepReward-b[i].stepReward};
}
function runAudit(root,frozenOverride){
  const {manifest,frozen:loaded}=loadFrozen(root);const frozen=frozenOverride??loaded;
  assert.deepEqual(frozen.baseSeeds,Array.from({length:600},(_,i)=>1200001+i),'exact existing seeds');
  assert.equal(frozen.steps,320);assert.equal(frozen.offsetAppliedBySimulator,10000);
  assert.deepEqual(frozen.policies.map(p=>p.key),['A2','S','N','C']);
  const policies=frozen.policies;
  const compiled=new Map();const saved=new Map();
  for(const p of policies){
    const ast=analyzeAndCompileCandidate(p.expr,DOMAIN_SCI.vars);
    assert(ast.stage1Valid);assert.equal(ast.nodes,p.nodes);assert.equal(ast.depth,p.depth);
    compiled.set(p.key,ast.fn);
    assert.deepEqual(p.perSeed.map(r=>r.seed),frozen.baseSeeds,'policy seeds');
    saved.set(p.key,new Map(p.perSeed.map(r=>[r.seed,r])));
  }
  const margins=[];const comparisons=[];const choices=[];
  for(const p of policies.slice(1)){
    const rows=frozen.baseSeeds.map(seed=>({comparator:p.key,seed,margin:saved.get('A2').get(seed).raw-saved.get(p.key).get(seed).raw}));
    margins.push(...rows);
    const sorted=rows.map(r=>r.margin).sort((a,b)=>a-b);
    comparisons.push({key:p.key,sessionId:p.sessionId,slotId:p.slotId,expr:p.expr,nodes:p.nodes,selectionUtility:p.selectionUtility,testUtility:p.utility,
      wins:rows.filter(r=>r.margin>TOL).length,ties:rows.filter(r=>Math.abs(r.margin)<=TOL).length,losses:rows.filter(r=>r.margin< -TOL).length,
      meanMargin:mean(sorted),worst30MeanMargin:mean(sorted.slice(0,30)),maximumLoss:Math.max(0,-sorted[0])});
    for(const sign of ['gain','loss']){
      const row=rows.find(r=>sign==='gain'?r.margin>TOL:r.margin< -TOL);
      assert(row,'both illustration signs must exist');choices.push({comparator:p.key,sign,seed:row.seed,traceMeanMargin:row.margin});
    }
  }
  const wanted=new Set(choices.map(c=>c.seed));const details=new Map();
  let currentRecords=null;
  const observed=makeObserved(r=>{if(currentRecords)currentRecords.push(r);});
  let maxSavedAbsoluteError=0,maxInstrumentationAbsoluteError=0;
  for(const seed of frozen.baseSeeds){
    const reference=DOMAIN_SCI.simulateTrace(DOMAIN_SCI.baselines['PID-lite'],seed,frozen.steps);
    for(const p of policies){
      const stored=saved.get(p.key).get(seed);
      assert.equal(stored.referenceRaw,reference,'saved reference reward');
      currentRecords=wanted.has(seed)?[]:null;
      const replay=observed(compiled.get(p.key),seed,frozen.steps);
      const original=DOMAIN_SCI.simulateTrace(compiled.get(p.key),seed,frozen.steps);
      maxSavedAbsoluteError=Math.max(maxSavedAbsoluteError,Math.abs(replay-stored.raw));
      maxInstrumentationAbsoluteError=Math.max(maxInstrumentationAbsoluteError,Math.abs(replay-original));
      assert.equal(replay,stored.raw,'saved reward mismatch '+p.key+' '+seed);
      assert.equal(replay,original,'observer changed original result');
      if(currentRecords){assert.equal(currentRecords.length,320);assert.equal(currentRecords.at(-1).cumulativeReward/320,replay);details.set(p.key+':'+seed,currentRecords);}
    }
  }
  const examples=choices.map(c=>{
    const a2=details.get('A2:'+c.seed),alternative=details.get(c.comparator+':'+c.seed);
    const divergence=firstDivergence(a2,alternative);
    const positiveSteps=a2.reduce((n,r,i)=>n+(r.stepReward-alternative[i].stepReward>TOL),0);
    const negativeSteps=a2.reduce((n,r,i)=>n+(r.stepReward-alternative[i].stepReward< -TOL),0);
    const diffMean=k=>mean(a2.map((r,i)=>r[k]-alternative[i][k]));
    const floor=r=>r.stepReward-(0.50+0.42*r.hazardMitigated-r.unnecessaryDerateLoss-0.14*r.packHazard);
    const rewardDecomposition={hazardCredit:0.42*diffMean('hazardMitigated'),unnecessaryPenalty:-diffMean('unnecessaryDerateLoss'),
      packPenalty:-0.14*diffMean('packHazard'),floorAdjustment:mean(a2.map((r,i)=>floor(r)-floor(alternative[i])))};
    assert(Math.abs(Object.values(rewardDecomposition).reduce((a,b)=>a+b,0)-c.traceMeanMargin)<TOL,'reward decomposition mismatch');
    return {...c,firstDivergence:divergence,actionDifferences:a2.filter((r,i)=>r.action!==alternative[i].action).length,
      positiveSteps,negativeSteps,tiedSteps:320-positiveSteps-negativeSteps,rewardDecomposition,a2,alternative};
  });
  return {policies:policies.map(({perSeed,...p})=>p),comparisons,margins,examples,
    verification:{result:'PASS',policySeedPairs:2400,referenceSeeds:600,stepsPerTrace:320,maxSavedAbsoluteError,maxInstrumentationAbsoluteError,
      distinctExistingSeeds:600,newModelCalls:0,newSeeds:0,independentNewObservations:0,illustrationPairs:6,
      firstDivergenceStatesIdentical:true,sourceHashesVerified:true,selectionRule:manifest.illustrationRule}};
}
function writeAudit(out,audit){
  fs.mkdirSync(out,{recursive:true});
  const write=(name,value)=>fs.writeFileSync(path.join(out,name),JSON.stringify(value,null,2)+'\n');
  write('comparison_summary.json',{policies:audit.policies,comparisons:audit.comparisons});
  write('examples.json',audit.examples);
  write('replay_verification.json',audit.verification);
  fs.writeFileSync(path.join(out,'all_seed_margins.csv'),'comparator,seed,margin\n'+audit.margins.map(r=>[r.comparator,r.seed,r.margin].join(',')).join('\n')+'\n');
  write('example_summary.json',audit.examples.map(({a2,alternative,...e})=>e));
}
if(require.main===module){
  const args=process.argv.slice(2);assert(args.length===0||(args.length===2&&args[0]==='--out'),'usage: node replay.cjs [--out DIRECTORY]');
  const audit=runAudit(__dirname);writeAudit(args[1]??path.join(__dirname,'results'),audit);
  console.log(JSON.stringify(audit.verification,null,2));
}
module.exports={loadFrozen,makeObserved,firstDivergence,runAudit,writeAudit};
