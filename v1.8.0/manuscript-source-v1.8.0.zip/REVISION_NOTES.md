# v1.8.0 revision

- Retain the exploratory title, original topic, A2 emphasis and A1 comparison-scope lesson.
- Add exact formulas and sizes for N and C; extend the existing Table 4 with their already-saved comparisons.
- Replace the invented A2 example with actual first-divergence inputs, policy scores and selected modules from two existing synthetic traces.
- Record both immediate and full-trace rewards, plus whole-trajectory reward accounting. Include the neutral comparison whose first divergence loses but full trace gains.
- Replace Figure 1 with cumulative replay differences; preserve prior figures/examples in earlier versions.
- Disclose retrospective example selection, original seeds, zero replay mismatch, state divergence, supplied-hint/reward overlap and unchanged causal/practical limits.
- Preserve original case expressions, primary outcomes, methods, references and earlier evidence. This adds local replay diagnostics, not model generation or a new validation set.
