# Submission materials v1.8.0

Cross-Domain Skill Composition: An Exploratory Study of Generated Policies

The exploratory cross-domain scope and five fixed cases remain. A2 is compared with a seven-node cubic policy (S), the highest selection-ranked neutral Thermal winner (N), and a same-size cubic/product policy (C). Table 2 now contains recorded states at first action divergence; Figure 1 shows complete cumulative trajectories. These replace the older invented A2 example and shape illustration in the paper. The older examples remain unchanged in v1.7.0.

Four existing policies were replayed locally on all 600 original seeds. All 2,400 policy-seed rewards and 600 references exactly match saved values. Six sign-conditioned example pairs and their first divergences are disclosed. Replay creates diagnostic logs, not new independent observations; it does not establish practical utility or cross-domain causation. No model calls or new seeds were used.

The official class, font defaults and margins are unchanged. There are 8 body pages, one references page and one required summary page (10 total), seven tables and three figures. Compile `main.tex` with `tectonic -X compile main.tex` and an available TeX bundle/cache. The independent analysis archive at https://github.com/7065616b/symbolic-policy-framing-pilot/tree/main/v1.8.0 includes its frozen inputs, unchanged simulator, observer code, tests and full records. Node.js reproduces the replay without network access. No conference submission was performed.
